
export type RewardTick = 'blue' | 'red' | 'green';
export type PackageType = 'free' | 'pro' | 'enterprise';

export interface User {
  id: string;
  email: string;
  name: string;
  username?: string;
  bio?: string;
  photoUrl?: string;
  joinDate: number;
  role: 'member' | 'founder';
  isOnboarded?: boolean;
  activeTick?: RewardTick;
  activePackage?: PackageType; // New property for package tracking
}

export type PostType = 'thought' | 'visual' | 'moment';

export interface Post {
  id: string;
  userId: string;
  authorName: string;
  authorPhoto?: string;
  type: PostType;
  content: string; // Text or Image URL
  caption?: string;
  timestamp: number;
  isFounder?: boolean;
  circleId?: string; // Optional: associate post with a circle
  rewardTick?: RewardTick; // Highlighted reward for specific posts
}

export interface Room {
  id: string;
  title: string;
  hostName: string;
  participantCount: number;
  isActive: boolean;
  type: 'audio' | 'video';
}

export interface Circle {
  id: string;
  name: string;
  description: string;
  coverImage: string;
  memberCount: number;
  tags: string[];
  ownerId: string;
  isPrivate: boolean;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export interface InviteRequest {
  id: string;
  name: string;
  email: string;
  intent: string;
  status: 'pending' | 'accepted' | 'rejected';
}
