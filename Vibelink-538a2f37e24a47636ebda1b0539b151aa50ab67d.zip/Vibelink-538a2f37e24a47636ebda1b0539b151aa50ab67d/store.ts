
import { Post, User, Room, InviteRequest, Circle, RewardTick } from './types';

const POSTS_KEY = 'vibelink_v2_posts';
const USERS_KEY = 'vibelink_v2_users';
const AUTH_KEY = 'vibelink_v2_auth';
const INVITES_KEY = 'vibelink_v2_invites';
const CIRCLES_KEY = 'vibelink_v2_circles';
const CIRCLE_MEMBERS_KEY = 'vibelink_v2_circle_members';

export const storage = {
  getAuth: (): User | null => {
    const data = localStorage.getItem(AUTH_KEY);
    return data ? JSON.parse(data) : null;
  },
  
  setAuth: (user: User | null) => {
    if (user) {
      localStorage.setItem(AUTH_KEY, JSON.stringify(user));
      const users = storage.getUsers();
      const exists = users.find(u => u.id === user.id);
      if (!exists) {
        localStorage.setItem(USERS_KEY, JSON.stringify([...users, user]));
      } else {
        const updated = users.map(u => u.id === user.id ? user : u);
        localStorage.setItem(USERS_KEY, JSON.stringify(updated));
      }
    } else {
      localStorage.removeItem(AUTH_KEY);
    }
  },

  getUsers: (): User[] => {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : [];
  },

  updateProfile: (userId: string, updates: Partial<User>) => {
    const users = storage.getUsers();
    const updated = users.map(u => u.id === userId ? { ...u, ...updates } : u);
    localStorage.setItem(USERS_KEY, JSON.stringify(updated));
    
    const currentAuth = storage.getAuth();
    if (currentAuth?.id === userId) {
      storage.setAuth({ ...currentAuth, ...updates } as User);
    }
  },

  getPosts: (circleId?: string): Post[] => {
    const data = localStorage.getItem(POSTS_KEY);
    const initial: Post[] = [
      {
        id: 'seed-1',
        userId: 'founder',
        authorName: 'OMKAR DUTTA',
        type: 'thought',
        content: 'The most important connections happen in the silence between notifications.',
        timestamp: Date.now() - 86400000,
        isFounder: true,
        rewardTick: 'blue'
      }
    ];
    let posts: Post[] = data ? JSON.parse(data) : initial;
    if (circleId) {
      return posts.filter(p => p.circleId === circleId);
    }
    return posts;
  },

  savePost: (post: Post) => {
    const posts = storage.getPosts();
    localStorage.setItem(POSTS_KEY, JSON.stringify([post, ...posts]));
  },

  updatePost: (id: string, content: string) => {
    const posts = storage.getPosts();
    const updated = posts.map(p => p.id === id ? { ...p, content } : p);
    localStorage.setItem(POSTS_KEY, JSON.stringify(updated));
  },

  getWeeklyWinners: () => {
    // In a real app, this would be computed server-side
    return [
      {
        userId: 'founder',
        name: 'Omkar Dutta',
        username: 'founder_omkar',
        tick: 'blue' as RewardTick,
        postId: 'seed-1',
        content: 'The most important connections happen in the silence...'
      },
      {
        userId: 'u2',
        name: 'Elena Rossi',
        username: 'elena_vfx',
        tick: 'red' as RewardTick,
        postId: 'post-99',
        content: 'High-fidelity aesthetics are the language of the soul.'
      },
      {
        userId: 'u3',
        name: 'Marcus Thorne',
        username: 'mthorne',
        tick: 'green' as RewardTick,
        postId: 'post-102',
        content: 'Resonance score reached 900 today. Digital sovereignty feels good.'
      }
    ];
  },

  getCircles: (): Circle[] => {
    const data = localStorage.getItem(CIRCLES_KEY);
    const initial: Circle[] = [
      {
        id: 'c1',
        name: 'Digital Stoics',
        description: 'Practicing digital minimalism and intentional living in a high-noise world.',
        coverImage: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&q=80&w=1080',
        memberCount: 124,
        tags: ['Minimalism', 'Philosophy'],
        ownerId: 'founder',
        isPrivate: false
      },
      {
        id: 'c2',
        name: 'Visual Sovereignty',
        description: 'Creators exploring high-fidelity aesthetics and digital identity.',
        coverImage: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&q=80&w=1080',
        memberCount: 89,
        tags: ['Design', 'Art'],
        ownerId: 'founder',
        isPrivate: false
      }
    ];
    return data ? JSON.parse(data) : initial;
  },

  getCircleById: (id: string): Circle | undefined => {
    return storage.getCircles().find(c => c.id === id);
  },

  saveCircle: (circle: Circle) => {
    const circles = storage.getCircles();
    localStorage.setItem(CIRCLES_KEY, JSON.stringify([circle, ...circles]));
  },

  updateCircle: (id: string, updates: Partial<Circle>) => {
    const circles = storage.getCircles();
    const updated = circles.map(c => c.id === id ? { ...c, ...updates } : c);
    localStorage.setItem(CIRCLES_KEY, JSON.stringify(updated));
  },

  getCircleMembers: (circleId: string): string[] => {
    const data = localStorage.getItem(`${CIRCLE_MEMBERS_KEY}_${circleId}`);
    return data ? JSON.parse(data) : [];
  },

  joinCircle: (circleId: string, userId: string) => {
    const members = storage.getCircleMembers(circleId);
    if (!members.includes(userId)) {
      localStorage.setItem(`${CIRCLE_MEMBERS_KEY}_${circleId}`, JSON.stringify([...members, userId]));
      const circles = storage.getCircles();
      const updated = circles.map(c => c.id === circleId ? { ...c, memberCount: c.memberCount + 1 } : c);
      localStorage.setItem(CIRCLES_KEY, JSON.stringify(updated));
    }
  },

  leaveCircle: (circleId: string, userId: string) => {
    const members = storage.getCircleMembers(circleId);
    const updatedMembers = members.filter(id => id !== userId);
    localStorage.setItem(`${CIRCLE_MEMBERS_KEY}_${circleId}`, JSON.stringify(updatedMembers));
    const circles = storage.getCircles();
    const updated = circles.map(c => c.id === circleId ? { ...c, memberCount: Math.max(0, c.memberCount - 1) } : c);
    localStorage.setItem(CIRCLES_KEY, JSON.stringify(updated));
  },

  getInvites: (): InviteRequest[] => {
    const data = localStorage.getItem(INVITES_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveInvite: (invite: InviteRequest) => {
    const invites = storage.getInvites();
    localStorage.setItem(INVITES_KEY, JSON.stringify([...invites, invite]));
  },

  getRooms: (): Room[] => [
    { id: 'r1', title: 'Late Night Philosophy', hostName: 'Omkar Dutta', participantCount: 12, isActive: true, type: 'audio' },
    { id: 'r2', title: 'Digital Sanctuary Design', hostName: 'Elena Rossi', participantCount: 5, isActive: true, type: 'video' }
  ]
};
