
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, PackageType } from '../types';
import { storage } from '../store';

interface AuthContextType {
  user: User | null;
  login: (email: string, password?: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  signup: (email: string, password?: string, name?: string) => Promise<void>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
  activatePackage: (pkg: PackageType) => Promise<void>;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(storage.getAuth());

  const login = async (email: string, password?: string) => {
    const users = storage.getUsers();
    const existingUser = users.find(u => u.email === email);
    
    if (existingUser) {
      setUser(existingUser);
      storage.setAuth(existingUser);
    } else {
      await signup(email, password, email.split('@')[0]);
    }
  };

  const loginWithGoogle = async () => {
    const googleUser: User = {
      id: 'google-' + Math.random().toString(36).substr(2, 9),
      email: 'google.user@gmail.com',
      name: 'Google Traveler',
      joinDate: Date.now(),
      role: 'member',
      bio: 'Journeying through the digital space via Google node.',
      isOnboarded: false,
      activePackage: 'free'
    };
    setUser(googleUser);
    storage.setAuth(googleUser);
  };

  const signup = async (email: string, password?: string, name?: string) => {
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      email,
      name: name || email.split('@')[0],
      joinDate: Date.now(),
      role: email === 'officialvibelink@gmail.com' ? 'founder' : 'member',
      bio: '',
      isOnboarded: false,
      activePackage: 'free'
    };
    setUser(newUser);
    storage.setAuth(newUser);
  };

  const logout = () => {
    setUser(null);
    storage.setAuth(null);
  };

  const updateProfile = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      storage.updateProfile(user.id, updates);
      setUser(updatedUser);
    }
  };

  const activatePackage = async (pkg: PackageType) => {
    if (user) {
      updateProfile({ activePackage: pkg });
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, loginWithGoogle, signup, logout, updateProfile, activatePackage, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
