
import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { RewardTick } from '../types';

interface BadgeProps {
  type: RewardTick;
  size?: number;
  className?: string;
}

const Badge: React.FC<BadgeProps> = ({ type, size = 16, className = "" }) => {
  const colors = {
    blue: 'text-blue-400 shadow-[0_0_15px_rgba(59,130,246,0.5)]',
    red: 'text-red-400 shadow-[0_0_15px_rgba(248,113,113,0.5)]',
    green: 'text-green-400 shadow-[0_0_15px_rgba(74,222,128,0.5)]'
  };

  return (
    <div className={`inline-flex items-center justify-center rounded-full bg-black/40 backdrop-blur-sm ${className}`}>
      <CheckCircle2 size={size} className={colors[type]} />
    </div>
  );
};

export default Badge;
