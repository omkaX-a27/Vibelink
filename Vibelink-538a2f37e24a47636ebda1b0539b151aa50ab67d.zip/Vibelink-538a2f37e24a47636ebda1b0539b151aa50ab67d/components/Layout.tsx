
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Command, User as UserIcon, Settings as SettingsIcon, LayoutDashboard } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import AuthModal from './AuthModal';
import Particles from './Particles';
import Footer from './Footer';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const location = useLocation();
  const { user, isAuthenticated, logout } = useAuth();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  const navLinks = [
    { name: 'Journal', path: '/live' },
    { name: 'Moments', path: '/stories' },
    { name: 'Circles', path: '/circles' },
    { name: 'Gatherings', path: '/rooms' },
    { name: 'Features', path: '/features' },
    { name: 'Pricing', path: '/pricing' },
    { name: 'Join', path: '/invite' },
  ];

  return (
    <div className="min-h-screen bg-black text-[#f5f5f7] flex flex-col relative overflow-x-hidden">
      <Particles />

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 apple-blur bg-black/60 border-b border-white/5">
        <div className="max-w-screen-md mx-auto px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-medium tracking-tight text-xl group">
            <Command size={22} className="text-white group-hover:rotate-180 transition-transform duration-700" />
            <span>Vibelink</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-[10px] uppercase font-bold tracking-widest transition-colors ${
                  location.pathname.startsWith(link.path) ? 'text-white' : 'text-zinc-500 hover:text-white'
                }`}
              >
                {link.name}
              </Link>
            ))}
            
            {isAuthenticated ? (
              <div className="flex items-center gap-4 ml-4">
                <Link to="/dashboard" className={`p-1.5 rounded-xl border border-white/5 hover:bg-white/5 transition-colors ${location.pathname === '/dashboard' ? 'bg-white/5 text-white' : 'text-zinc-500'}`}>
                  <LayoutDashboard size={18} />
                </Link>
                <Link to="/settings" className={`p-1.5 rounded-xl border border-white/5 hover:bg-white/5 transition-colors ${location.pathname === '/settings' ? 'bg-white/5 text-white' : 'text-zinc-500'}`}>
                  <SettingsIcon size={18} />
                </Link>
                <button 
                  onClick={logout}
                  className="text-[9px] uppercase tracking-[0.2em] font-black text-zinc-600 hover:text-red-400"
                >
                  Exit
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setIsAuthModalOpen(true)}
                className="text-xs uppercase tracking-widest font-bold bg-white text-black px-5 py-2 rounded-full hover:bg-zinc-200 transition-all"
              >
                Enter
              </button>
            )}
          </div>

          {/* Mobile Toggle */}
          <div className="flex items-center gap-4 md:hidden">
            {!isAuthenticated && (
              <button onClick={() => setIsAuthModalOpen(true)} className="p-2 text-zinc-400">
                <UserIcon size={22} />
              </button>
            )}
            <button 
              className="p-2 text-zinc-400 hover:text-white transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-black pt-24 px-8 md:hidden flex flex-col gap-6"
          >
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className="text-4xl font-semibold tracking-tighter text-zinc-200 hover:text-white transition-all"
              >
                {link.name}
              </Link>
            ))}
            {isAuthenticated && (
              <>
                <Link to="/dashboard" className="text-4xl font-semibold tracking-tighter text-teal-400">
                  Console
                </Link>
                <Link to="/settings" className="text-4xl font-semibold tracking-tighter text-white">
                  Settings
                </Link>
              </>
            )}
            <div className="mt-auto pb-12 text-zinc-700 text-[10px] tracking-[0.3em] font-bold uppercase">
              Quiet Network • Node Established 2024
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="pt-16 flex-1 flex flex-col relative z-10">
        {children}
      </main>

      <Footer />

      <AuthModal isOpen={isAuthModalOpen} onClose={() => setIsAuthModalOpen(false)} />
    </div>
  );
};

export default Layout;
