
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, Sparkles, Zap, Shield, Command, CheckCircle2, Loader2 } from 'lucide-react';
import Reveal from './Reveal';
import MagneticButton from './MagneticButton';
import { useAuth } from '../context/AuthContext';
import { PackageType } from '../types';

const PLANS = [
  {
    id: 'free' as PackageType,
    name: "Free Package",
    price: "$0",
    description: "Instant Entry Signal",
    features: [
      "Basic posting",
      "Limited streaming",
      "Community feed access",
      "Standard encryption"
    ],
    accent: "zinc-800"
  },
  {
    id: 'pro' as PackageType,
    name: "Pro Plan",
    price: "$29",
    description: "Full Fidelity",
    features: [
      "Unlimited streaming",
      "Advanced analytics",
      "Monetization tools",
      "Priority signal routing",
      "Custom marketplace node"
    ],
    accent: "teal-400",
    popular: true
  },
  {
    id: 'enterprise' as PackageType,
    name: "Enterprise",
    price: "Custom",
    description: "Infrastructure",
    features: [
      "Dedicated bandwidth",
      "Custom feature development",
      "White-label options",
      "Direct API integration",
      "Concierge support"
    ],
    accent: "white"
  }
];

const PackagesSection: React.FC = () => {
  const { user, activatePackage, isAuthenticated } = useAuth();
  const [loadingPkg, setLoadingPkg] = useState<PackageType | null>(null);
  const [successPkg, setSuccessPkg] = useState<PackageType | null>(null);

  const handleActivate = async (pkgId: PackageType) => {
    if (!isAuthenticated) return;
    
    setLoadingPkg(pkgId);
    
    // Simulate activation delay
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    await activatePackage(pkgId);
    
    setLoadingPkg(null);
    setSuccessPkg(pkgId);
    
    setTimeout(() => setSuccessPkg(null), 3000);
  };

  return (
    <div className="relative">
      {/* Toast Notification */}
      <AnimatePresence>
        {successPkg && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-12 left-1/2 -translate-x-1/2 z-[200] px-8 py-4 bg-white text-black rounded-full font-bold shadow-2xl flex items-center gap-3"
          >
            <CheckCircle2 size={20} className="text-green-600" />
            <span>{successPkg === 'free' ? 'Free Package Activated' : 'Plan Successfully Updated'}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-40">
        {PLANS.map((plan, idx) => {
          const isActive = user?.activePackage === plan.id;
          const isLoading = loadingPkg === plan.id;

          return (
            <Reveal key={plan.id} delay={idx * 0.1} direction="up">
              <div className={`relative p-10 rounded-[2.5rem] bg-zinc-950/50 border h-full flex flex-col group transition-all duration-500 hover:bg-zinc-900/40 ${
                isActive ? 'border-teal-500 shadow-[0_0_30px_rgba(45,212,191,0.1)]' : 'border-white/5'
              }`}>
                {plan.popular && !isActive && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-teal-400 text-black text-[10px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full shadow-[0_0_20px_rgba(45,212,191,0.3)]">
                    Most Resonant
                  </div>
                )}

                {isActive && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-white text-black text-[10px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full shadow-[0_0_20px_rgba(255,255,255,0.2)] flex items-center gap-1.5">
                    <CheckCircle2 size={12} /> Currently Active
                  </div>
                )}
                
                <div className="mb-8">
                  <h3 className="text-xs uppercase tracking-widest font-bold text-zinc-500 mb-2">{plan.name}</h3>
                  <div className="flex items-baseline gap-1">
                    <span className="text-4xl font-semibold text-white">{plan.price}</span>
                    {plan.price !== 'Custom' && <span className="text-zinc-600 text-sm">/mo</span>}
                  </div>
                  <p className="text-zinc-500 text-sm font-light mt-2 italic">{plan.description}</p>
                </div>

                <div className="space-y-4 mb-12 flex-1">
                  {plan.features.map((feature, fIdx) => (
                    <div key={fIdx} className="flex items-center gap-3 text-sm text-zinc-400 font-light">
                      <Check size={14} className={isActive || plan.popular ? 'text-teal-400' : 'text-zinc-600'} />
                      {feature}
                    </div>
                  ))}
                </div>

                <MagneticButton 
                  onClick={() => handleActivate(plan.id)}
                  disabled={isActive || isLoading}
                  className={`w-full py-4 rounded-2xl font-bold transition-all ${
                    isActive 
                      ? 'bg-zinc-900 text-zinc-500 cursor-default' 
                      : plan.popular 
                        ? 'bg-teal-400 text-black hover:bg-teal-300' 
                        : 'bg-white text-black hover:bg-zinc-200'
                  }`}
                >
                  {isLoading ? (
                    <Loader2 size={18} className="animate-spin mx-auto" />
                  ) : isActive ? (
                    'Selected'
                  ) : (
                    plan.id === 'free' ? 'Activate Now' : `Upgrade to ${plan.id}`
                  )}
                </MagneticButton>
              </div>
            </Reveal>
          );
        })}
      </div>
    </div>
  );
};

export default PackagesSection;
