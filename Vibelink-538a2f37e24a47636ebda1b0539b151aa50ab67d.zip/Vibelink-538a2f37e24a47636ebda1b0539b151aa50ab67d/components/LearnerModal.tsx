
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Cpu, Globe, Send, CheckCircle } from 'lucide-react';
import { useModal } from '../context/ModalContext';

const LearnerModal: React.FC = () => {
  const { isOpen, closeModal } = useModal();
  const [step, setStep] = useState<'form' | 'success'>('form');
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    city: '',
    state: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call
    setTimeout(() => {
      setStep('success');
      setTimeout(() => {
        closeModal();
        setStep('form');
        setFormData({ name: '', phone: '', email: '', city: '', state: '' });
      }, 3000);
    }, 800);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeModal}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />

          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-lg bg-zinc-950 border border-white/10 rounded-[2.5rem] overflow-hidden shadow-2xl shadow-white/5"
          >
            {/* Futuristic Background Elements */}
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/20 to-transparent" />
            <div className="absolute -top-24 -right-24 w-48 h-48 bg-white/5 rounded-full blur-3xl" />
            
            <div className="p-8 md:p-12">
              <button
                onClick={closeModal}
                className="absolute top-6 right-6 p-2 text-zinc-500 hover:text-white transition-colors"
              >
                <X size={24} />
              </button>

              <AnimatePresence mode="wait">
                {step === 'form' ? (
                  <motion.div
                    key="form"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                  >
                    <div className="flex items-center gap-3 mb-6">
                      <div className="p-2 bg-white/5 rounded-lg">
                        <Cpu size={24} className="text-white" />
                      </div>
                      <h2 className="text-2xl font-semibold tracking-tight text-white">Initialize Access</h2>
                    </div>

                    <p className="text-zinc-400 font-light mb-8 leading-relaxed">
                      Sync with the Vibelink network. Provide your credentials to proceed into the space.
                    </p>

                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] uppercase tracking-widest text-zinc-600 font-bold px-1">Identity</label>
                          <input
                            required
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            className="w-full bg-black border border-white/5 rounded-2xl px-5 py-3.5 text-white focus:outline-none focus:border-white/20 transition-all placeholder:text-zinc-800"
                            placeholder="Full Name"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] uppercase tracking-widest text-zinc-600 font-bold px-1">Signal Link</label>
                          <input
                            required
                            type="tel"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            className="w-full bg-black border border-white/5 rounded-2xl px-5 py-3.5 text-white focus:outline-none focus:border-white/20 transition-all placeholder:text-zinc-800"
                            placeholder="Contact Number"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[10px] uppercase tracking-widest text-zinc-600 font-bold px-1">Network Node</label>
                        <input
                          required
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          className="w-full bg-black border border-white/5 rounded-2xl px-5 py-3.5 text-white focus:outline-none focus:border-white/20 transition-all placeholder:text-zinc-800"
                          placeholder="Email Address"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-[10px] uppercase tracking-widest text-zinc-600 font-bold px-1">Geo Sector</label>
                          <input
                            required
                            name="city"
                            value={formData.city}
                            onChange={handleChange}
                            className="w-full bg-black border border-white/5 rounded-2xl px-5 py-3.5 text-white focus:outline-none focus:border-white/20 transition-all placeholder:text-zinc-800"
                            placeholder="City"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] uppercase tracking-widest text-zinc-600 font-bold px-1">Zone</label>
                          <input
                            required
                            name="state"
                            value={formData.state}
                            onChange={handleChange}
                            className="w-full bg-black border border-white/5 rounded-2xl px-5 py-3.5 text-white focus:outline-none focus:border-white/20 transition-all placeholder:text-zinc-800"
                            placeholder="State"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full mt-6 group flex items-center justify-center gap-2 bg-white text-black py-4 rounded-2xl font-semibold hover:bg-zinc-200 transition-all active:scale-95"
                      >
                        Transmit Signal
                        <Send size={18} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                      </button>
                    </form>
                  </motion.div>
                ) : (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex flex-col items-center justify-center py-12 text-center"
                  >
                    <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-6">
                      <CheckCircle size={48} className="text-white" />
                    </div>
                    <h2 className="text-2xl font-semibold text-white mb-3">Transmission Successful</h2>
                    <p className="text-zinc-500 font-light max-w-xs leading-relaxed">
                      Your data has been integrated into the Vibelink grid. We will reach out shortly.
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default LearnerModal;
