
import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, Github, Command } from 'lucide-react';

const Footer: React.FC = () => {
  const socials = [
    { 
      icon: Instagram, 
      href: 'https://www.instagram.com/phenomenal.pablo?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==', 
      label: 'Instagram' 
    },
    { 
      icon: Twitter, 
      href: 'https://twitter.com', 
      label: 'X' 
    },
    { 
      icon: Github, 
      href: 'https://github.com/omkaX-a27', 
      label: 'GitHub' 
    },
    { 
      icon: Facebook, 
      href: 'https://www.facebook.com/profile.php?id=100073335111073', 
      label: 'Facebook' 
    },
  ];

  const footLinks = [
    { name: 'Features', path: '/features' },
    { name: 'Pricing', path: '/pricing' },
    { name: 'Legal', path: '/legal' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <footer className="bg-black border-t border-white/5 py-20 px-6 mt-auto">
      <div className="max-w-screen-md mx-auto grid grid-cols-1 md:grid-cols-2 gap-12">
        <div className="space-y-8">
          <div className="flex items-center gap-2 font-medium tracking-tight text-xl">
            <Command size={22} className="text-white" />
            <span>Vibelink</span>
          </div>
          <p className="text-zinc-500 font-light max-w-xs leading-relaxed">
            A sanctuary for intentional connections. Join the quiet revolution of high-signal digital living.
          </p>
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            {footLinks.map((link) => (
              <Link 
                key={link.path} 
                to={link.path} 
                className="text-xs uppercase tracking-widest font-bold text-zinc-600 hover:text-zinc-300 transition-colors"
              >
                {link.name}
              </Link>
            ))}
          </div>
          <div className="pt-4 text-[10px] text-zinc-700 tracking-widest uppercase">
            © 2024 Vibelink Ecosystem. All rights reserved.
          </div>
        </div>

        <div className="space-y-8">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-400 mb-6">Follow Us</h4>
            <div className="flex flex-wrap gap-4">
              {socials.map((social) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.1, backgroundColor: 'rgba(255,255,255,0.05)' }}
                  whileTap={{ scale: 0.95 }}
                  className="w-12 h-12 flex items-center justify-center rounded-2xl border border-white/5 bg-white/[0.02] text-zinc-400 hover:text-white transition-colors"
                  aria-label={social.label}
                >
                  <social.icon size={20} />
                </motion.a>
              ))}
            </div>
          </div>

          <div className="pt-4">
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-400 mb-4">Foundation</h4>
            <div className="text-sm font-light text-zinc-500">
              Founder: <span className="text-zinc-300 font-medium">Omkar Dutta</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
