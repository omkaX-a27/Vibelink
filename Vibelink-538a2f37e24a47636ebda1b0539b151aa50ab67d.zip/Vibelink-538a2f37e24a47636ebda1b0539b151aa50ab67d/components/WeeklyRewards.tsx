
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, Clock, ChevronRight, Sparkles, User as UserIcon } from 'lucide-react';
import { storage } from '../store';
import Badge from './Badge';
import Reveal from './Reveal';
import MagneticButton from './MagneticButton';
import { useNavigate } from 'react-router-dom';

const WeeklyRewards: React.FC = () => {
  const [winners, setWinners] = useState<any[]>([]);
  const [timeLeft, setTimeLeft] = useState({ days: 3, hours: 14, mins: 42 });
  const navigate = useNavigate();

  useEffect(() => {
    setWinners(storage.getWeeklyWinners());
    
    const interval = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.mins > 0) return { ...prev, mins: prev.mins - 1 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, mins: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, mins: 59 };
        return prev;
      });
    }, 60000);
    
    return () => clearInterval(interval);
  }, []);

  const topWinner = winners.find(w => w.tick === 'blue');
  const others = winners.filter(w => w.tick !== 'blue');

  return (
    <section className="py-24 px-6 border-t border-white/5 bg-gradient-to-b from-black via-zinc-950/20 to-black">
      <div className="max-w-screen-lg mx-auto">
        <header className="flex flex-col md:flex-row items-end justify-between gap-8 mb-16">
          <Reveal>
            <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-4 flex items-center gap-2">
              <Trophy size={14} className="text-yellow-500/50" />
              Recognition
            </h2>
            <h1 className="text-4xl md:text-6xl font-semibold text-white tracking-tighter">Weekly Sovereignty.</h1>
          </Reveal>
          
          <Reveal delay={0.3}>
            <div className="flex items-center gap-6 px-6 py-3 rounded-full bg-white/5 border border-white/5 backdrop-blur-xl">
              <div className="flex items-center gap-2 text-zinc-500">
                <Clock size={16} />
                <span className="text-[10px] uppercase font-bold tracking-widest">Cycle Ends</span>
              </div>
              <div className="flex gap-3 font-mono text-sm text-white">
                <span>{timeLeft.days}d</span>
                <span className="text-zinc-700">:</span>
                <span>{timeLeft.hours}h</span>
                <span className="text-zinc-700">:</span>
                <span>{timeLeft.mins}m</span>
              </div>
            </div>
          </Reveal>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-12">
          {/* Top Winner - Blue Tick */}
          <div className="md:col-span-7">
            <Reveal direction="right">
              <motion.div 
                whileHover={{ y: -5 }}
                className="relative p-1 bg-gradient-to-br from-blue-500/20 via-transparent to-transparent rounded-[3.5rem] overflow-hidden group"
              >
                <div className="bg-zinc-950 border border-white/5 rounded-[3.4rem] p-10 h-full">
                  <div className="flex items-start justify-between mb-8">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-[1.5rem] bg-zinc-900 border border-white/5 flex items-center justify-center text-zinc-700 relative">
                        <UserIcon size={24} />
                        <Badge type="blue" size={24} className="absolute -bottom-1 -right-1 p-1" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-semibold text-white tracking-tight">{topWinner?.name}</h3>
                        <p className="text-xs text-zinc-500 uppercase tracking-widest font-bold">@{topWinner?.username}</p>
                      </div>
                    </div>
                    <div className="px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-[10px] font-bold uppercase tracking-widest">
                      Ascendant
                    </div>
                  </div>

                  <div className="space-y-6">
                    <p className="text-2xl font-light text-zinc-300 leading-relaxed italic">
                      "{topWinner?.content}"
                    </p>
                    <div className="pt-6 border-t border-white/5 flex items-center justify-between">
                      <div className="text-[10px] uppercase tracking-widest text-zinc-600 font-bold">Resonance Awarded for Clarity</div>
                      <MagneticButton 
                        onClick={() => navigate('/live')}
                        className="text-xs text-white flex items-center gap-2 group/btn"
                      >
                        View Signal <ChevronRight size={14} className="group-hover/btn:translate-x-1 transition-transform" />
                      </MagneticButton>
                    </div>
                  </div>
                </div>
              </motion.div>
            </Reveal>
          </div>

          {/* Other Winners */}
          <div className="md:col-span-5 flex flex-col gap-8">
            {others.map((winner, idx) => (
              <Reveal key={winner.userId} delay={0.2 + idx * 0.1} direction="up">
                <motion.div 
                  whileHover={{ x: 5 }}
                  className="bg-zinc-950/50 border border-white/5 rounded-[2.5rem] p-6 flex items-center gap-6 group hover:border-white/10 transition-colors"
                >
                  <div className="relative">
                    <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-white/5 flex items-center justify-center text-zinc-700">
                      <UserIcon size={18} />
                    </div>
                    <Badge type={winner.tick} size={18} className="absolute -bottom-1 -right-1 p-0.5" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-medium tracking-tight">{winner.name}</h4>
                    <p className="text-[9px] text-zinc-600 uppercase tracking-widest font-bold">@{winner.username}</p>
                    <p className="text-sm text-zinc-500 font-light mt-1 line-clamp-1 italic">"{winner.content}"</p>
                  </div>
                  <ChevronRight size={18} className="text-zinc-800 group-hover:text-white transition-colors" />
                </motion.div>
              </Reveal>
            ))}

            <Reveal delay={0.5}>
              <div className="p-8 rounded-[2.5rem] bg-zinc-900/20 border border-dashed border-white/10 text-center space-y-4">
                <div className="w-10 h-10 rounded-full bg-white/5 mx-auto flex items-center justify-center text-zinc-500">
                  <Sparkles size={20} />
                </div>
                <div>
                  <h4 className="text-white font-medium text-sm">Your Signal Next?</h4>
                  <p className="text-[10px] text-zinc-600 uppercase tracking-widest font-bold mt-1">Consistency is key to recognition.</p>
                </div>
                <MagneticButton 
                  onClick={() => navigate('/live')}
                  className="w-full bg-white text-black py-3 rounded-xl font-bold text-xs"
                >
                  Post to Live Feed
                </MagneticButton>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WeeklyRewards;
