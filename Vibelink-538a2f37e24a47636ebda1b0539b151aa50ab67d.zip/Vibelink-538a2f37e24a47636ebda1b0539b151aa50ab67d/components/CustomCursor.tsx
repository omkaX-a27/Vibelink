
import React, { useEffect, useState } from 'react';
import { motion, useSpring, useMotionValue } from 'framer-motion';

const CustomCursor: React.FC = () => {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const [isHovering, setIsHovering] = useState(false);

  const springConfig = { damping: 25, stiffness: 200 };
  const trailX = useSpring(mouseX, springConfig);
  const trailY = useSpring(mouseY, springConfig);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);

      const target = e.target as HTMLElement;
      setIsHovering(!!target.closest('button, a, input, textarea, [role="button"], .clickable'));
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [mouseX, mouseY]);

  return (
    <div className="fixed inset-0 pointer-events-none z-[9999] hidden md:block">
      {/* Main glowing teal dot */}
      <motion.div
        className="absolute w-2 h-2 bg-teal-400 rounded-full shadow-[0_0_10px_#2dd4bf]"
        style={{ left: mouseX, top: mouseY, x: '-50%', y: '-50%' }}
      />
      {/* Outer trailing teal ring */}
      <motion.div
        className="absolute w-8 h-8 border-2 border-teal-500/30 rounded-full"
        animate={{
          scale: isHovering ? 2 : 1,
          borderColor: isHovering ? 'rgba(45, 212, 191, 0.8)' : 'rgba(45, 212, 191, 0.3)',
          boxShadow: isHovering ? '0 0 20px rgba(45, 212, 191, 0.4)' : 'none'
        }}
        style={{ left: trailX, top: trailY, x: '-50%', y: '-50%' }}
      />
    </div>
  );
};

export default CustomCursor;
