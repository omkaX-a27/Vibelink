
import React from 'react';
import { HashRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import Layout from './components/Layout';
import Home from './pages/Home';
import Live from './pages/Live';
import Stories from './pages/Stories';
import Rooms from './pages/Rooms';
import Philosophy from './pages/Philosophy';
import Invite from './pages/Invite';
import Contact from './pages/Contact';
import Dashboard from './pages/Dashboard';
import Pricing from './pages/Pricing';
import Features from './pages/Features';
import Legal from './pages/Legal';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import Onboarding from './pages/Onboarding';
import Circles from './pages/Circles';
import CircleDetail from './pages/CircleDetail';
import { ModalProvider } from './context/ModalContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import LearnerModal from './components/LearnerModal';

const OnboardingRedirect = ({ children }: { children?: React.ReactNode }) => {
  const { user, isAuthenticated } = useAuth();
  if (isAuthenticated && user && !user.isOnboarded) {
    return <Navigate to="/onboard" replace />;
  }
  return <>{children}</>;
};

const AnimatedRoutes = () => {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<Home />} />
        <Route path="/onboard" element={<Onboarding />} />
        <Route path="/live" element={<OnboardingRedirect><Live /></OnboardingRedirect>} />
        <Route path="/stories" element={<OnboardingRedirect><Stories /></OnboardingRedirect>} />
        <Route path="/rooms" element={<OnboardingRedirect><Rooms /></OnboardingRedirect>} />
        <Route path="/circles" element={<OnboardingRedirect><Circles /></OnboardingRedirect>} />
        <Route path="/circles/:id" element={<OnboardingRedirect><CircleDetail /></OnboardingRedirect>} />
        <Route path="/philosophy" element={<Philosophy />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/invite" element={<Invite />} />
        <Route path="/dashboard" element={<OnboardingRedirect><Dashboard /></OnboardingRedirect>} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/features" element={<Features />} />
        <Route path="/legal" element={<Legal />} />
        <Route path="/profile" element={<OnboardingRedirect><Profile /></OnboardingRedirect>} />
        <Route path="/settings" element={<OnboardingRedirect><Settings /></OnboardingRedirect>} />
      </Routes>
    </AnimatePresence>
  );
};

const App = () => {
  return (
    <AuthProvider>
      <ModalProvider>
        <Router>
          <Layout>
            <AnimatedRoutes />
          </Layout>
        </Router>
        <LearnerModal />
      </ModalProvider>
    </AuthProvider>
  );
};

export default App;
