
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { storage } from '../store';
import { Post } from '../types';
import { useAuth } from '../context/AuthContext';
import { Send, Image as ImageIcon, Sparkles, User as UserIcon } from 'lucide-react';
import Reveal from '../components/Reveal';
import Badge from '../components/Badge';

const SkeletonCard = () => (
  <div className="p-8 rounded-[2.5rem] border border-white/5 bg-zinc-950/20 mb-6 shimmer-bg">
    <div className="flex items-center gap-3 mb-6">
      <div className="w-12 h-12 rounded-2xl bg-zinc-900/50" />
      <div className="space-y-2">
        <div className="w-24 h-3 bg-zinc-900/50 rounded" />
        <div className="w-16 h-2 bg-zinc-900/30 rounded" />
      </div>
    </div>
    <div className="pl-16 space-y-3">
      <div className="w-full h-4 bg-zinc-900/50 rounded" />
      <div className="w-5/6 h-4 bg-zinc-900/50 rounded" />
      <div className="w-2/3 h-4 bg-zinc-900/50 rounded" />
    </div>
  </div>
);

const Live: React.FC = () => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [content, setContent] = useState('');
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    const timer = setTimeout(() => {
      setPosts(storage.getPosts());
      setIsLoading(false);
    }, 1500); // 1.5s delay to appreciate the shimmer
    return () => clearTimeout(timer);
  }, []);

  const handlePost = () => {
    if (!content.trim() || !user) return;
    
    // Simulate Automatic Award Logic: 10% chance to get a tick on post
    const random = Math.random();
    let awardedTick: any = undefined;
    if (random > 0.95) awardedTick = 'blue';
    else if (random > 0.85) awardedTick = 'red';
    else if (random > 0.7) awardedTick = 'green';

    const newPost: Post = {
      id: Date.now().toString(),
      userId: user.id,
      authorName: user.name,
      type: 'thought',
      content: content.trim(),
      timestamp: Date.now(),
      isFounder: user.role === 'founder',
      rewardTick: awardedTick
    };

    storage.savePost(newPost);
    setPosts([newPost, ...posts]);
    setContent('');
  };

  return (
    <div className="max-w-screen-md mx-auto px-6 py-20 pb-40">
      <header className="mb-16">
        <Reveal>
          <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-4">Chronicle</h2>
          <h1 className="text-5xl font-semibold text-white tracking-tighter">The Living Journal</h1>
        </Reveal>
      </header>

      {isAuthenticated && (
        <Reveal delay={0.4}>
          <div className="mb-16 p-8 rounded-[2.5rem] bg-zinc-950/50 border border-white/5 group focus-within:border-white/20 transition-all">
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Share an intentional thought..."
              className="w-full bg-transparent border-none text-xl font-light text-white placeholder:text-zinc-700 focus:outline-none resize-none min-h-[120px]"
            />
            <div className="flex items-center justify-between pt-6 border-t border-white/5">
              <div className="flex gap-4">
                <button className="p-2 text-zinc-600 hover:text-zinc-400 transition-colors">
                  <ImageIcon size={20} />
                </button>
                <button className="p-2 text-zinc-600 hover:text-zinc-400 transition-colors">
                  <Sparkles size={20} />
                </button>
              </div>
              <button
                onClick={handlePost}
                disabled={!content.trim()}
                className="flex items-center gap-2 bg-white text-black px-8 py-3 rounded-full font-bold hover:bg-zinc-200 disabled:opacity-20 transition-all active:scale-95"
              >
                Transmit <Send size={16} />
              </button>
            </div>
          </div>
        </Reveal>
      )}

      <div className="space-y-16">
        <AnimatePresence mode="popLayout">
          {isLoading ? (
            <motion.div
              key="skeletons"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-12"
            >
              <SkeletonCard />
              <SkeletonCard />
              <SkeletonCard />
            </motion.div>
          ) : (
            posts.map((post, idx) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ 
                  delay: idx * 0.05, 
                  duration: 0.8, 
                  ease: [0.22, 1, 0.36, 1] 
                }}
                className="group"
              >
                <div className="flex items-center gap-4 mb-6">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-transform duration-500 group-hover:scale-110 relative ${post.isFounder ? 'bg-white text-black' : 'bg-zinc-900 text-zinc-500'}`}>
                    <UserIcon size={20} />
                    {post.rewardTick && (
                      <Badge type={post.rewardTick} size={14} className="absolute -bottom-1 -right-1 p-0.5 border border-black" />
                    )}
                  </div>
                  <div>
                    <h4 className={`font-medium tracking-tight flex items-center gap-2 ${post.isFounder ? 'text-white' : 'text-zinc-300'}`}>
                      {post.authorName}
                      {post.isFounder && <span className="text-[10px] uppercase font-bold tracking-widest text-zinc-500">Founder</span>}
                    </h4>
                    <p className="text-[10px] text-zinc-600 uppercase tracking-widest font-bold">
                      {new Date(post.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
                
                <div className="pl-16">
                  <p className="text-xl md:text-2xl font-light text-zinc-400 leading-relaxed tracking-tight group-hover:text-zinc-200 transition-colors duration-500">
                    {post.content}
                  </p>
                </div>
                
                <div className="mt-8 ml-16 h-[1px] bg-white/5 w-1/4 group-hover:w-full transition-all duration-1000 ease-out" />
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Live;
