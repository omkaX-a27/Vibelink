
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { storage } from '../store';
import { Mic, Video, Users, ArrowUpRight } from 'lucide-react';
import Reveal from '../components/Reveal';
import MagneticButton from '../components/MagneticButton';
import { Room } from '../types';

const SkeletonRoomCard = () => (
  <div className="p-10 rounded-[3rem] border border-white/5 bg-zinc-950/20 animate-pulse h-[280px] flex flex-col justify-between">
    <div className="space-y-4">
      <div className="h-8 w-48 bg-zinc-900 rounded-lg" />
      <div className="h-4 w-32 bg-zinc-900 rounded-lg" />
    </div>
    <div className="space-y-6">
      <div className="flex gap-4">
        <div className="h-4 w-20 bg-zinc-900 rounded-lg" />
        <div className="h-4 w-12 bg-zinc-900 rounded-lg" />
      </div>
      <div className="h-14 w-40 bg-zinc-900 rounded-full" />
    </div>
  </div>
);

const Rooms: React.FC = () => {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setRooms(storage.getRooms());
      setIsLoading(false);
    }, 1200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-screen-md mx-auto px-6 py-20"
    >
      <header className="mb-16">
        <Reveal>
          <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-4">Gatherings</h2>
          <h1 className="text-5xl font-semibold text-white tracking-tighter">Community Circles</h1>
          <p className="text-zinc-500 font-light mt-6 text-xl leading-relaxed">
            Intentional spaces for voice and presence. No broadcast, just conversation.
          </p>
        </Reveal>
      </header>

      <div className="grid gap-8">
        {isLoading ? (
          <>
            <SkeletonRoomCard />
            <SkeletonRoomCard />
          </>
        ) : (
          rooms.map((room, idx) => (
            <Reveal key={room.id} delay={idx * 0.2} direction="up">
              <div className="p-10 rounded-[3rem] bg-zinc-950/50 border border-white/5 hover:border-white/10 transition-all group relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8">
                  {room.type === 'audio' ? <Mic size={24} className="text-teal-400" /> : <Video size={24} className="text-purple-400" />}
                </div>
                
                <div className="space-y-6 relative z-10">
                  <div>
                    <h3 className="text-3xl font-medium text-white tracking-tight mb-2">{room.title}</h3>
                    <p className="text-zinc-500 font-light">Hosted by <span className="text-zinc-300">{room.hostName}</span></p>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2 text-zinc-400 text-sm">
                      <Users size={16} />
                      <span>{room.participantCount} in circle</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-pulse" />
                      <span className="text-[10px] uppercase font-bold tracking-widest text-teal-400">Live</span>
                    </div>
                  </div>

                  <MagneticButton className="bg-white text-black px-10 py-4 rounded-full font-bold flex items-center gap-2 group-hover:bg-zinc-200 transition-all">
                    Join Circle <ArrowUpRight size={18} />
                  </MagneticButton>
                </div>

                <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-teal-500/5 rounded-full blur-[80px] pointer-events-none" />
              </div>
            </Reveal>
          ))
        )}
      </div>

      <section className="mt-32 p-12 rounded-[3rem] bg-zinc-900/30 border border-white/5 text-center">
        <Reveal>
          <h3 className="text-2xl font-medium text-white mb-4">Start a Gathering?</h3>
          <p className="text-zinc-500 font-light mb-8 max-w-sm mx-auto">
            Founder or Pro members can initiate intentional gatherings at any time.
          </p>
          <button className="text-teal-400 font-medium underline underline-offset-8">Apply for Host Rights</button>
        </Reveal>
      </section>
    </motion.div>
  );
};

export default Rooms;
