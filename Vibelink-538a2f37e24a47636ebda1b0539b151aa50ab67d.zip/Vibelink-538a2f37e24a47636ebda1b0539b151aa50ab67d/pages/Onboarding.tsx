
import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { 
  Camera, 
  ArrowRight, 
  Check, 
  Shield, 
  Sparkles, 
  Bell, 
  Moon, 
  ChevronRight,
  User as UserIcon,
  Globe
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import Reveal from '../components/Reveal';
import MagneticButton from '../components/MagneticButton';

type OnboardingStep = 'welcome' | 'identity' | 'essence' | 'frequency';

const Onboarding: React.FC = () => {
  const { user, updateProfile } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState<OnboardingStep>('welcome');
  const [formData, setFormData] = useState({
    name: user?.name || '',
    username: '',
    bio: '',
    photoUrl: '',
    notifications: true,
    theme: 'dark'
  });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleNext = () => {
    if (step === 'welcome') setStep('identity');
    else if (step === 'identity') setStep('essence');
    else if (step === 'essence') setStep('frequency');
    else {
      updateProfile({
        name: formData.name,
        username: formData.username,
        bio: formData.bio,
        photoUrl: formData.photoUrl,
        isOnboarded: true
      });
      navigate('/dashboard');
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setFormData({ ...formData, photoUrl: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-white/5 rounded-full blur-[120px]" />
      </div>

      <div className="max-w-md w-full relative z-10">
        <AnimatePresence mode="wait">
          {step === 'welcome' && (
            <motion.div
              key="welcome"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-center"
            >
              <Reveal direction="down">
                <div className="w-20 h-20 rounded-3xl bg-white/5 border border-white/10 flex items-center justify-center text-white mx-auto mb-10">
                  <Sparkles size={40} />
                </div>
                <h1 className="text-5xl font-semibold text-white tracking-tighter mb-6">Welcome to the Space.</h1>
                <p className="text-zinc-500 font-light text-xl leading-relaxed mb-12">
                  Vibelink is a quiet network. Before we integrate your node, let's define your presence.
                </p>
                <MagneticButton 
                  onClick={handleNext}
                  className="bg-white text-black px-12 py-5 rounded-full font-bold shadow-2xl mx-auto"
                >
                  Initialize Setup <ArrowRight size={20} className="ml-2" />
                </MagneticButton>
              </Reveal>
            </motion.div>
          )}

          {step === 'identity' && (
            <motion.div
              key="identity"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-12"
            >
              <header>
                <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-2">Signal Identity</h2>
                <h1 className="text-4xl font-semibold text-white tracking-tight">Who are you?</h1>
              </header>

              <div className="space-y-6">
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-widest text-zinc-500 px-1 font-bold">Public Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-zinc-950 border border-white/10 rounded-2xl px-6 py-4 text-white text-lg focus:outline-none focus:border-white/30 transition-all placeholder:text-zinc-800"
                    placeholder="e.g. Elena Rossi"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-widest text-zinc-500 px-1 font-bold">Node Address (Username)</label>
                  <div className="relative">
                    <span className="absolute left-6 top-1/2 -translate-y-1/2 text-zinc-600">@</span>
                    <input
                      type="text"
                      value={formData.username}
                      onChange={(e) => setFormData({ ...formData, username: e.target.value.toLowerCase().replace(/\s/g, '') })}
                      className="w-full bg-zinc-950 border border-white/10 rounded-2xl pl-10 pr-6 py-4 text-white text-lg focus:outline-none focus:border-white/30 transition-all placeholder:text-zinc-800"
                      placeholder="username"
                    />
                  </div>
                </div>
              </div>

              <MagneticButton 
                onClick={handleNext}
                disabled={!formData.name || !formData.username}
                className="w-full bg-white text-black py-5 rounded-full font-bold disabled:opacity-20 transition-all"
              >
                Next <ChevronRight size={20} className="ml-2" />
              </MagneticButton>
            </motion.div>
          )}

          {step === 'essence' && (
            <motion.div
              key="essence"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-12"
            >
              <header>
                <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-2">Presence Essence</h2>
                <h1 className="text-4xl font-semibold text-white tracking-tight">The Visual & Voice.</h1>
              </header>

              <div className="flex flex-col items-center gap-8">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-32 h-32 rounded-[2.5rem] bg-zinc-900 border border-white/10 flex items-center justify-center overflow-hidden cursor-pointer group relative shadow-2xl"
                >
                  {formData.photoUrl ? (
                    <img src={formData.photoUrl} className="w-full h-full object-cover" alt="Profile" />
                  ) : (
                    <UserIcon size={40} className="text-zinc-700" />
                  )}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Camera size={24} className="text-white" />
                  </div>
                </div>
                <input type="file" ref={fileInputRef} className="hidden" onChange={handlePhotoUpload} accept="image/*" />

                <div className="w-full space-y-1">
                  <label className="text-[10px] uppercase tracking-widest text-zinc-500 px-1 font-bold">Philosophy / Bio</label>
                  <textarea
                    rows={4}
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                    className="w-full bg-zinc-950 border border-white/10 rounded-2xl px-6 py-4 text-white text-lg font-light focus:outline-none focus:border-white/30 transition-all resize-none placeholder:text-zinc-800"
                    placeholder="Share your frequency with the network..."
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => setStep('identity')}
                  className="flex-1 py-5 rounded-full border border-white/5 text-zinc-500 font-bold hover:text-white transition-all"
                >
                  Back
                </button>
                <MagneticButton 
                  onClick={handleNext}
                  className="flex-[2] bg-white text-black py-5 rounded-full font-bold"
                >
                  Continue <ChevronRight size={20} className="ml-2" />
                </MagneticButton>
              </div>
            </motion.div>
          )}

          {step === 'frequency' && (
            <motion.div
              key="frequency"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-12"
            >
              <header>
                <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-2">Node Tuning</h2>
                <h1 className="text-4xl font-semibold text-white tracking-tight">Preferences.</h1>
              </header>

              <div className="bg-zinc-950/50 border border-white/5 rounded-[2.5rem] overflow-hidden">
                <div className="flex items-center justify-between p-6 border-b border-white/5">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-2xl bg-white/5 text-zinc-400">
                      <Bell size={20} />
                    </div>
                    <div>
                      <p className="text-white font-medium">Notifications</p>
                      <p className="text-[10px] text-zinc-600 uppercase font-bold tracking-widest">Minimal Signal Only</p>
                    </div>
                  </div>
                  <div 
                    onClick={() => setFormData({ ...formData, notifications: !formData.notifications })}
                    className={`w-12 h-7 rounded-full transition-all relative cursor-pointer ${formData.notifications ? 'bg-white' : 'bg-zinc-800'}`}
                  >
                    <motion.div 
                      animate={{ x: formData.notifications ? 22 : 4 }}
                      className={`absolute top-1 w-5 h-5 rounded-full ${formData.notifications ? 'bg-black' : 'bg-zinc-500'}`} 
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-2xl bg-white/5 text-zinc-400">
                      <Moon size={20} />
                    </div>
                    <div>
                      <p className="text-white font-medium">Theme</p>
                      <p className="text-[10px] text-zinc-600 uppercase font-bold tracking-widest">OLED Midnight</p>
                    </div>
                  </div>
                  <Check size={20} className="text-teal-400" />
                </div>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => setStep('essence')}
                  className="flex-1 py-5 rounded-full border border-white/5 text-zinc-500 font-bold hover:text-white transition-all"
                >
                  Back
                </button>
                <MagneticButton 
                  onClick={handleNext}
                  className="flex-[2] bg-white text-black py-5 rounded-full font-bold shadow-[0_0_40px_rgba(255,255,255,0.1)]"
                >
                  Complete Integration <Check size={20} className="ml-2" />
                </MagneticButton>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Onboarding;
