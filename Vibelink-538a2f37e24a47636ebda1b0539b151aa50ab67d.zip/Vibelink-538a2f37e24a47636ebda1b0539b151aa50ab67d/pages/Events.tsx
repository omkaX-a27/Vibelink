
import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, PlusCircle, Zap } from 'lucide-react';
import { useModal } from '../context/ModalContext';

const EVENTS = [
  {
    id: 'e1',
    title: 'Minimalist Design Discourse',
    date: 'Oct 24, 2024',
    time: '20:00 GMT',
    type: 'Exclusive',
    description: 'A deep dive into the philosophy of "Less but Better" with the Vibelink founding team.'
  },
  {
    id: 'e2',
    title: 'Silent Coding Session',
    date: 'Oct 28, 2024',
    time: '04:00 GMT',
    type: 'Open Session',
    description: 'A focus session with ambient lo-fi and zero interruptions.'
  },
  {
    id: 'e3',
    title: 'Digital Minimalism Workshop',
    date: 'Nov 02, 2024',
    time: '18:30 GMT',
    type: 'Pro Masterclass',
    description: 'Practical steps to reclaiming your attention in an era of noise.'
  }
];

const Events: React.FC = () => {
  const { openModal } = useModal();

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-screen-md mx-auto px-6 py-12"
    >
      <header className="mb-12">
        <h2 className="text-sm font-medium uppercase tracking-[0.2em] text-zinc-500 mb-2">Live Sessions</h2>
        <h1 className="text-4xl font-semibold text-white tracking-tight">Gatherings</h1>
      </header>

      <div className="space-y-8">
        {EVENTS.map((event, idx) => (
          <motion.div
            key={event.id}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: idx * 0.1 }}
            className="group relative p-8 rounded-[2rem] bg-zinc-950 border border-white/5 hover:border-white/10 transition-all duration-500 overflow-hidden"
          >
            {/* Visual background hint */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/[0.02] rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl group-hover:bg-white/[0.05] transition-all" />

            <div className="flex flex-col md:flex-row md:items-center gap-6 relative z-10">
              <div className="flex-1">
                <div className="flex flex-wrap items-center gap-4 text-xs font-medium text-zinc-500 mb-3 uppercase tracking-wider">
                  <div className="flex items-center gap-1.5"><Calendar size={14} /> {event.date}</div>
                  <div className="flex items-center gap-1.5"><Clock size={14} /> {event.time}</div>
                  <div className="flex items-center gap-1.5 text-zinc-400 bg-white/5 px-2 py-0.5 rounded"><Zap size={12} /> {event.type}</div>
                </div>
                <h3 className="text-2xl font-medium text-white mb-2 group-hover:text-zinc-300 transition-colors">
                  {event.title}
                </h3>
                <p className="text-zinc-500 font-light leading-relaxed mb-6 md:mb-0">
                  {event.description}
                </p>
              </div>
              <button 
                onClick={openModal}
                className="h-14 px-8 md:w-14 md:px-0 flex items-center justify-center gap-3 rounded-full bg-white/5 border border-white/5 text-zinc-400 group-hover:bg-white group-hover:text-black transition-all duration-300 whitespace-nowrap"
              >
                <span className="md:hidden font-semibold">Reserve Spot</span>
                <PlusCircle size={24} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="mt-16 p-12 rounded-[3rem] bg-white text-black text-center relative overflow-hidden"
      >
        <div className="relative z-10">
          <h2 className="text-3xl font-semibold mb-4">Host a Gathering?</h2>
          <p className="text-zinc-600 font-light mb-8 max-w-sm mx-auto">
            Bring your high-signal ideas to the Vibelink community. Apply for session hosting rights.
          </p>
          <button 
            onClick={openModal}
            className="bg-black text-white px-10 py-4 rounded-full font-bold hover:scale-105 transition-transform"
          >
            Become a Guide
          </button>
        </div>
        {/* Subtle pattern background for the card */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, black 1px, transparent 0)', backgroundSize: '24px 24px' }} />
      </motion.div>
    </motion.div>
  );
};

export default Events;
