
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, 
  Users, 
  Shield, 
  Settings, 
  MoreVertical, 
  Send, 
  Image as ImageIcon,
  User as UserIcon,
  CheckCircle,
  LogOut,
  Edit2
} from 'lucide-react';
import { storage } from '../store';
import { Circle, Post } from '../types';
import { useAuth } from '../context/AuthContext';
import Reveal from '../components/Reveal';
import MagneticButton from '../components/MagneticButton';

const CircleDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const [circle, setCircle] = useState<Circle | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [content, setContent] = useState('');
  const [isMember, setIsMember] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdminMode, setIsAdminMode] = useState(false);

  useEffect(() => {
    if (id) {
      const circleData = storage.getCircleById(id);
      if (circleData) {
        setCircle(circleData);
        setPosts(storage.getPosts(id));
        setIsMember(user ? storage.getCircleMembers(id).includes(user.id) : false);
      }
      setIsLoading(false);
    }
  }, [id, user]);

  const handlePost = () => {
    if (!content.trim() || !user || !id) return;
    
    const newPost: Post = {
      id: Date.now().toString(),
      userId: user.id,
      authorName: user.name,
      type: 'thought',
      content: content.trim(),
      timestamp: Date.now(),
      isFounder: user.role === 'founder',
      circleId: id
    };

    storage.savePost(newPost);
    setPosts([newPost, ...posts]);
    setContent('');
  };

  const handleJoinToggle = () => {
    if (!user || !id || !circle) return;
    if (isMember) {
      storage.leaveCircle(id, user.id);
      setIsMember(false);
    } else {
      storage.joinCircle(id, user.id);
      setIsMember(true);
    }
    setCircle(storage.getCircleById(id) || null);
  };

  const isFounder = user?.role === 'founder';

  if (isLoading) return <div className="min-h-screen bg-black" />;
  if (!circle) return <div className="p-20 text-center text-white">Circle not found.</div>;

  return (
    <div className="bg-black min-h-screen pb-40">
      {/* Hero Header */}
      <header className="relative h-[40vh] overflow-hidden">
        <img src={circle.coverImage} className="absolute inset-0 w-full h-full object-cover opacity-60" alt={circle.name} />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
        
        <div className="absolute top-8 left-6 md:left-12">
          <button 
            onClick={() => navigate('/circles')}
            className="p-3 rounded-full bg-black/40 backdrop-blur-xl border border-white/10 text-white hover:bg-white/10 transition-colors"
          >
            <ArrowLeft size={24} />
          </button>
        </div>

        <div className="absolute bottom-12 left-6 md:left-12 right-6 md:right-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-4">
            <div className="flex gap-2">
              {circle.tags.map(tag => (
                <span key={tag} className="text-[10px] uppercase tracking-widest font-bold text-white/60 bg-white/10 px-2 py-0.5 rounded backdrop-blur-xl border border-white/5">
                  {tag}
                </span>
              ))}
            </div>
            <h1 className="text-5xl md:text-7xl font-semibold text-white tracking-tighter">{circle.name}</h1>
            <div className="flex items-center gap-6 text-zinc-400 text-sm">
              <div className="flex items-center gap-2">
                <Users size={18} />
                <span>{circle.memberCount} Members</span>
              </div>
              {isFounder && (
                <div className="flex items-center gap-2 text-teal-400">
                  <Shield size={16} />
                  <span className="text-[10px] uppercase font-black tracking-widest">Founder Access</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-4">
            {isFounder && (
              <button 
                onClick={() => setIsAdminMode(!isAdminMode)}
                className={`p-4 rounded-2xl border transition-all ${isAdminMode ? 'bg-teal-500 border-teal-400 text-white' : 'bg-black/40 border-white/10 text-white hover:bg-white/10'}`}
              >
                <Settings size={22} />
              </button>
            )}
            <MagneticButton 
              onClick={handleJoinToggle}
              className={`px-10 py-4 rounded-full font-bold transition-all ${
                isMember ? 'bg-white/10 text-white border border-white/10' : 'bg-white text-black'
              }`}
            >
              {isMember ? <><LogOut size={18} className="mr-2" /> Leave</> : 'Join Circle'}
            </MagneticButton>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="max-w-screen-md mx-auto px-6 mt-16 grid grid-cols-1 gap-12">
        
        {/* Admin Dashboard */}
        <AnimatePresence>
          {isAdminMode && isFounder && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden mb-8"
            >
              <div className="bg-teal-500/5 border border-teal-500/20 rounded-[2.5rem] p-8">
                <h3 className="text-xs uppercase tracking-[0.4em] font-bold text-teal-400 mb-6">Moderation Terminal</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button className="flex items-center justify-between p-6 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 transition-colors">
                    <div className="text-left">
                      <p className="text-white font-medium">Edit Sanctuary</p>
                      <p className="text-[10px] text-zinc-600 uppercase font-bold tracking-widest mt-1">Appearance & Bio</p>
                    </div>
                    <Edit2 size={18} className="text-zinc-500" />
                  </button>
                  <button className="flex items-center justify-between p-6 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 transition-colors">
                    <div className="text-left">
                      <p className="text-white font-medium">Clear All Noise</p>
                      <p className="text-[10px] text-zinc-600 uppercase font-bold tracking-widest mt-1">Moderate Posts</p>
                    </div>
                    <Shield size={18} className="text-zinc-500" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <section className="space-y-12">
          {isMember && (
            <Reveal>
              <div className="p-8 rounded-[2.5rem] bg-zinc-950/50 border border-white/5 focus-within:border-white/20 transition-all">
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder={`Contribute to the ${circle.name} frequency...`}
                  className="w-full bg-transparent border-none text-xl font-light text-white placeholder:text-zinc-700 focus:outline-none resize-none min-h-[120px]"
                />
                <div className="flex items-center justify-between pt-6 border-t border-white/5">
                  <div className="flex gap-4">
                    <button className="p-2 text-zinc-600 hover:text-zinc-400 transition-colors">
                      <ImageIcon size={20} />
                    </button>
                  </div>
                  <button
                    onClick={handlePost}
                    disabled={!content.trim()}
                    className="flex items-center gap-2 bg-white text-black px-8 py-3 rounded-full font-bold hover:bg-zinc-200 disabled:opacity-20 transition-all active:scale-95"
                  >
                    Transmit <Send size={16} />
                  </button>
                </div>
              </div>
            </Reveal>
          )}

          <div className="space-y-12">
            {posts.length > 0 ? (
              posts.map((post, idx) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="group relative"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${post.isFounder ? 'bg-white text-black' : 'bg-zinc-900 text-zinc-500'}`}>
                        <UserIcon size={18} />
                      </div>
                      <div>
                        <h4 className="font-medium text-white tracking-tight flex items-center gap-2">
                          {post.authorName}
                          {post.isFounder && <CheckCircle size={12} className="text-teal-400" />}
                        </h4>
                        <p className="text-[9px] text-zinc-600 uppercase tracking-widest font-black">
                          {new Date(post.timestamp).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    {isFounder && (
                      <button className="p-2 text-zinc-800 hover:text-red-400 transition-colors">
                        <MoreVertical size={18} />
                      </button>
                    )}
                  </div>
                  <div className="pl-14">
                    <p className="text-lg md:text-xl font-light text-zinc-400 leading-relaxed group-hover:text-zinc-200 transition-colors duration-500">
                      {post.content}
                    </p>
                  </div>
                  <div className="mt-8 ml-14 h-[1px] bg-white/5 group-hover:bg-white/10 transition-colors" />
                </motion.div>
              ))
            ) : (
              <div className="py-20 text-center">
                <p className="text-zinc-800 italic font-light">The circle is quiet. Be the first to emit a signal.</p>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

export default CircleDetail;
