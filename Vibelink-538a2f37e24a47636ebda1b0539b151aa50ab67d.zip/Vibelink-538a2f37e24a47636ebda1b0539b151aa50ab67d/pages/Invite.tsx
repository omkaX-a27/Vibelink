
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { storage } from '../store';
import { CheckCircle2 } from 'lucide-react';

const Invite: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: '', intent: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    storage.saveInvite({
      id: Math.random().toString(36).substr(2, 9),
      ...formData,
      status: 'pending'
    });
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] px-6 text-center"
      >
        <CheckCircle2 size={64} className="text-zinc-400 mb-6" />
        <h1 className="text-3xl font-medium text-white mb-2">Request Received</h1>
        <p className="text-zinc-500 font-light max-w-xs mx-auto">
          Our curation team will review your application. Good things take time.
        </p>
      </motion.div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-screen-sm mx-auto px-6 py-20"
    >
      <header className="mb-12 text-center">
        <h1 className="text-4xl font-semibold text-white tracking-tight mb-4">Request Access</h1>
        <p className="text-zinc-500 font-light text-lg">
          Join a community built on intent and calm.
        </p>
      </header>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="space-y-1">
          <label className="text-[10px] uppercase tracking-widest font-bold text-zinc-500 px-1">Your Name</label>
          <input
            required
            type="text"
            className="w-full bg-zinc-950 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-white/30 transition-colors"
            placeholder="John Doe"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
        </div>

        <div className="space-y-1">
          <label className="text-[10px] uppercase tracking-widest font-bold text-zinc-500 px-1">Email Address</label>
          <input
            required
            type="email"
            className="w-full bg-zinc-950 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-white/30 transition-colors"
            placeholder="hello@example.com"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          />
        </div>

        <div className="space-y-1">
          <label className="text-[10px] uppercase tracking-widest font-bold text-zinc-500 px-1">Why Vibelink?</label>
          <textarea
            required
            rows={4}
            className="w-full bg-zinc-950 border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-white/30 transition-colors resize-none"
            placeholder="Tell us what brings you here..."
            value={formData.intent}
            onChange={(e) => setFormData({ ...formData, intent: e.target.value })}
          />
        </div>

        <button
          type="submit"
          className="w-full py-5 rounded-2xl bg-white text-black font-semibold hover:bg-zinc-200 transition-colors active:scale-[0.98] duration-200"
        >
          Submit Request
        </button>
      </form>
    </motion.div>
  );
};

export default Invite;
