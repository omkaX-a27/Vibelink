
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import { User as UserIcon, Calendar, Edit3, ShieldCheck, MapPin } from 'lucide-react';
import Reveal from '../components/Reveal';
import MagneticButton from '../components/MagneticButton';

const SkeletonProfileHeader = () => (
  <div className="flex flex-col md:flex-row items-center gap-12 mb-20 animate-pulse">
    <div className="w-40 h-40 rounded-[2.5rem] bg-zinc-900 border border-white/5" />
    <div className="flex-1 space-y-4 w-full text-center md:text-left">
      <div className="h-10 w-48 bg-zinc-900 rounded-lg mx-auto md:mx-0" />
      <div className="flex justify-center md:justify-start gap-6">
        <div className="h-4 w-24 bg-zinc-900 rounded-lg" />
        <div className="h-4 w-24 bg-zinc-900 rounded-lg" />
      </div>
      <div className="h-12 w-full max-w-sm bg-zinc-900 rounded-lg mx-auto md:mx-0" />
    </div>
  </div>
);

const Profile: React.FC = () => {
  // Fix: Corrected updateBio to updateProfile
  const { user, updateProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [newBio, setNewBio] = useState(user?.bio || '');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);

  if (!user && !isLoading) return null;

  const handleSave = () => {
    // Fix: Using updateProfile instead of non-existent updateBio
    updateProfile({ bio: newBio });
    setIsEditing(false);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-screen-md mx-auto px-6 py-20"
    >
      {isLoading ? (
        <SkeletonProfileHeader />
      ) : (
        <header className="flex flex-col md:flex-row items-center gap-12 mb-20">
          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-40 h-40 rounded-[2.5rem] bg-zinc-900 border border-white/5 flex items-center justify-center text-zinc-700 relative group overflow-hidden"
          >
            <UserIcon size={64} />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <Edit3 size={24} className="text-white" />
            </div>
          </motion.div>

          <div className="flex-1 text-center md:text-left space-y-4">
            <div>
              <div className="flex items-center justify-center md:justify-start gap-3 mb-2">
                <h1 className="text-4xl font-semibold text-white tracking-tighter">{user?.name}</h1>
                {user?.role === 'founder' && <ShieldCheck className="text-teal-400" size={24} />}
              </div>
              <div className="flex flex-wrap justify-center md:justify-start gap-6 text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500">
                <span className="flex items-center gap-1.5"><Calendar size={12} /> Since {user ? new Date(user.joinDate).getFullYear() : '---'}</span>
                <span className="flex items-center gap-1.5"><MapPin size={12} /> Kolkata Grid</span>
              </div>
            </div>

            <div className="relative">
              {isEditing ? (
                <div className="space-y-4">
                  <textarea
                    value={newBio}
                    onChange={(e) => setNewBio(e.target.value)}
                    maxLength={100}
                    className="w-full bg-zinc-950 border border-white/10 rounded-2xl p-4 text-white focus:outline-none focus:border-white/30 resize-none font-light"
                    rows={2}
                  />
                  <button onClick={handleSave} className="text-xs uppercase font-bold tracking-widest text-teal-400">Update Signal</button>
                </div>
              ) : (
                <p 
                  onClick={() => setIsEditing(true)}
                  className="text-xl font-light text-zinc-400 leading-relaxed italic cursor-pointer hover:text-zinc-300 transition-colors"
                >
                  "{user?.bio || 'Add a resonance bio...'}"
                </p>
              )}
            </div>
          </div>
        </header>
      )}

      <section className="space-y-12">
        <Reveal>
          <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-8">Recent Resonance</h2>
          <div className={`text-center py-20 rounded-[3rem] border border-dashed border-white/5 ${isLoading ? 'animate-pulse bg-zinc-950/20' : ''}`}>
            {isLoading ? null : (
              <p className="text-zinc-600 font-light italic">No public contributions yet.</p>
            )}
          </div>
        </Reveal>
      </section>
    </motion.div>
  );
};

export default Profile;
