
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  Shield, 
  Bell, 
  Smartphone, 
  Lock, 
  Trash2, 
  ChevronRight, 
  Moon, 
  Globe, 
  Check,
  Camera
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import Reveal from '../components/Reveal';
import MagneticButton from '../components/MagneticButton';

const SettingsSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="mb-12">
    <h3 className="text-[10px] uppercase tracking-[0.3em] font-bold text-zinc-600 mb-4 px-2">{title}</h3>
    <div className="bg-zinc-950/50 border border-white/5 rounded-[2rem] overflow-hidden">
      {children}
    </div>
  </div>
);

const SettingRow: React.FC<{ 
  icon: any; 
  label: string; 
  value?: string; 
  onClick?: () => void; 
  showToggle?: boolean;
  isToggled?: boolean;
  onToggle?: () => void;
  isDanger?: boolean;
}> = ({ icon: Icon, label, value, onClick, showToggle, isToggled, onToggle, isDanger }) => (
  <button 
    onClick={onClick}
    className="w-full flex items-center gap-4 px-6 py-5 hover:bg-white/[0.02] transition-colors border-b border-white/5 last:border-0 group"
  >
    <div className={`p-2 rounded-xl bg-white/5 ${isDanger ? 'text-red-400' : 'text-zinc-500 group-hover:text-white transition-colors'}`}>
      <Icon size={18} />
    </div>
    <div className="flex-1 text-left">
      <p className={`text-sm font-medium ${isDanger ? 'text-red-400' : 'text-zinc-300'}`}>{label}</p>
      {value && <p className="text-[10px] text-zinc-600 uppercase tracking-widest font-bold mt-0.5">{value}</p>}
    </div>
    {showToggle ? (
      <div 
        onClick={(e) => { e.stopPropagation(); onToggle?.(); }}
        className={`w-10 h-6 rounded-full transition-all relative ${isToggled ? 'bg-white' : 'bg-zinc-800'}`}
      >
        <motion.div 
          animate={{ x: isToggled ? 18 : 2 }}
          className={`absolute top-1 w-4 h-4 rounded-full ${isToggled ? 'bg-black' : 'bg-zinc-500'}`} 
        />
      </div>
    ) : (
      <ChevronRight size={16} className="text-zinc-700" />
    )}
  </button>
);

const Settings: React.FC = () => {
  const { user, updateBio, logout } = useAuth();
  const [notifs, setNotifs] = useState(true);
  const [privacy, setPrivacy] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 2000);
    }, 1000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-screen-md mx-auto px-6 py-20 pb-40"
    >
      <header className="mb-16">
        <Reveal>
          <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-4">Core Node</h2>
          <h1 className="text-5xl font-semibold text-white tracking-tighter">System Settings</h1>
        </Reveal>
      </header>

      <div className="space-y-4">
        <SettingsSection title="Identity">
          <div className="p-8 flex items-center gap-6 border-b border-white/5">
            <div className="relative group cursor-pointer">
              <div className="w-20 h-20 rounded-[1.5rem] bg-zinc-900 border border-white/5 flex items-center justify-center text-zinc-700">
                <User size={32} />
              </div>
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-[1.5rem]">
                <Camera size={20} className="text-white" />
              </div>
            </div>
            <div>
              <h4 className="text-xl font-medium text-white tracking-tight">{user?.name}</h4>
              <p className="text-xs text-zinc-500 font-light">{user?.email}</p>
            </div>
          </div>
          <SettingRow icon={User} label="Profile Bio" value={user?.bio || 'No bio set'} />
          <SettingRow icon={Smartphone} label="Username" value={`@${user?.name?.toLowerCase().replace(/\s/g, '')}`} />
        </SettingsSection>

        <SettingsSection title="Interface">
          <SettingRow 
            icon={Bell} 
            label="Push Notifications" 
            showToggle 
            isToggled={notifs} 
            onToggle={() => setNotifs(!notifs)} 
          />
          <SettingRow 
            icon={Shield} 
            label="Private Mode" 
            showToggle 
            isToggled={privacy} 
            onToggle={() => setPrivacy(!privacy)} 
          />
          <SettingRow icon={Moon} label="Display Theme" value="Midnight (OLED)" />
          <SettingRow icon={Globe} label="Language" value="English (Universal)" />
        </SettingsSection>

        <SettingsSection title="Security">
          <SettingRow icon={Lock} label="Two-Factor Authentication" value="Off" />
          <SettingRow icon={Smartphone} label="Logged Devices" value="1 Node Active" />
        </SettingsSection>

        <SettingsSection title="Danger Zone">
          <SettingRow icon={Trash2} label="Deactivate Account" isDanger />
          <SettingRow icon={Trash2} label="Purge Identity (Delete)" isDanger onClick={logout} />
        </SettingsSection>

        <div className="pt-8 flex items-center justify-between">
          <button className="text-xs text-zinc-600 hover:text-white transition-colors uppercase tracking-widest font-bold">Reset Defaults</button>
          <MagneticButton 
            onClick={handleSave}
            className={`px-10 py-4 rounded-full font-bold transition-all ${success ? 'bg-green-500 text-white' : 'bg-white text-black'}`}
          >
            {isSaving ? 'Syncing...' : success ? 'Synchronized' : 'Save Changes'}
            {success && <Check size={18} className="ml-2" />}
          </MagneticButton>
        </div>
      </div>
    </motion.div>
  );
};

export default Settings;
