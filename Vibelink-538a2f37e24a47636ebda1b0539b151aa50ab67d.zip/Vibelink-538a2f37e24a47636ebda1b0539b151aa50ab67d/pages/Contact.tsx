
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Globe, MessageSquare, Send, CheckCircle, MapPin } from 'lucide-react';
import Reveal from '../components/Reveal';
import MagneticButton from '../components/MagneticButton';

const Contact: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-screen-md mx-auto px-6 py-20"
    >
      <header className="mb-20 text-center">
        <Reveal>
          <h2 className="text-sm font-medium uppercase tracking-[0.3em] text-zinc-500 mb-4">Transmission</h2>
          <h1 className="text-5xl md:text-7xl font-semibold text-white tracking-tighter mb-6">Contact Us</h1>
          <p className="text-zinc-500 font-light text-lg max-w-sm mx-auto leading-relaxed">
            Reach out through the grid. Our neural nodes are always listening.
          </p>
        </Reveal>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
        <div className="space-y-12">
          <Reveal direction="right" delay={0.4}>
            <div className="space-y-6">
              <h3 className="text-xs uppercase tracking-[0.2em] font-bold text-zinc-600">Channels</h3>
              <div className="space-y-6">
                <div className="flex items-center gap-4 group">
                  <div className="p-4 rounded-2xl bg-white/5 text-zinc-500 group-hover:text-teal-400 transition-colors"><Mail size={22} /></div>
                  <div>
                    <p className="text-xs text-zinc-600 uppercase font-bold tracking-widest">Email</p>
                    <p className="text-white font-light">officialvibelink@gmail.com</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 group">
                  <div className="p-4 rounded-2xl bg-white/5 text-zinc-500 group-hover:text-teal-400 transition-colors"><MessageSquare size={22} /></div>
                  <div>
                    <p className="text-xs text-zinc-600 uppercase font-bold tracking-widest">Support</p>
                    <p className="text-white font-light">node-support.vibelink</p>
                  </div>
                </div>
                <div className="flex items-center gap-4 group">
                  <div className="p-4 rounded-2xl bg-white/5 text-zinc-500 group-hover:text-teal-400 transition-colors"><MapPin size={22} /></div>
                  <div>
                    <p className="text-xs text-zinc-600 uppercase font-bold tracking-widest">Hub</p>
                    <p className="text-white font-light">Kolkata Node 03, India</p>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>
        </div>

        <div className="relative">
          <Reveal direction="left" delay={0.6}>
            <motion.div
              className="bg-zinc-950/50 border border-white/5 rounded-[2.5rem] p-10 backdrop-blur-xl relative overflow-hidden"
            >
              {submitted ? (
                <motion.div 
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex flex-col items-center justify-center py-20 text-center"
                >
                  <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-6">
                    <CheckCircle size={32} className="text-teal-400" />
                  </div>
                  <h3 className="text-xl font-medium text-white mb-2">Message Encrypted</h3>
                  <p className="text-zinc-500 font-light text-sm">Synchronizing with the Kolkata grid.</p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase tracking-widest font-bold text-zinc-600 px-1">Identity</label>
                    <input required className="w-full bg-black border border-white/5 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-teal-500/50 transition-all placeholder:text-zinc-800" placeholder="Your Name" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase tracking-widest font-bold text-zinc-600 px-1">Signal Node</label>
                    <input required type="email" className="w-full bg-black border border-white/5 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-teal-500/50 transition-all placeholder:text-zinc-800" placeholder="Email Address" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase tracking-widest font-bold text-zinc-600 px-1">Packet Data</label>
                    <textarea required rows={4} className="w-full bg-black border border-white/5 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-teal-500/50 transition-all placeholder:text-zinc-800 resize-none" placeholder="Your Message" />
                  </div>
                  <MagneticButton 
                    className="w-full bg-white text-black py-4 rounded-2xl font-bold shadow-xl shadow-white/5"
                  >
                    Broadcast
                    <Send size={18} />
                  </MagneticButton>
                </form>
              )}
              {/* Visual scanline effect */}
              <div className="absolute inset-0 pointer-events-none opacity-[0.03] bg-[linear-gradient(transparent_0%,rgba(255,255,255,0.1)_50%,transparent_100%)] bg-[length:100%_4px] animate-pulse" />
            </motion.div>
          </Reveal>
        </div>
      </div>
    </motion.div>
  );
};

export default Contact;
