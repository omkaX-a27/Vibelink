
import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Sparkles, User, Github, Instagram, Facebook } from 'lucide-react';
import Reveal from '../components/Reveal';

const Philosophy: React.FC = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-screen-md mx-auto px-8 py-24 pb-40"
    >
      <div className="space-y-24">
        <section>
          <Reveal direction="down">
            <h1 className="text-6xl md:text-8xl font-semibold text-white tracking-tighter mb-12">
              The Manifesto.
            </h1>
          </Reveal>
          <Reveal delay={0.4}>
            <p className="text-2xl md:text-3xl font-light text-zinc-300 leading-relaxed tracking-tight">
              We are drowning in noise. Vibelink is the anti-metric, built for those who appreciate the silence between notes.
            </p>
          </Reveal>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {[
            { 
              title: "Intent", 
              desc: "Connectivity shouldn't be constant. It should be meaningful. High-signal interactions that respect your cognitive space." 
            },
            { 
              title: "Digital Sovereignty", 
              desc: "You are not data. Your moments are yours. Vibelink is built on the principle of absolute privacy." 
            }
          ].map((item, i) => (
            <Reveal key={i} delay={0.2 * i} direction="up">
              <div className="space-y-4 p-8 rounded-[2rem] bg-zinc-950/50 border border-white/5 hover:border-teal-500/10 transition-colors">
                <h3 className="text-xs uppercase tracking-widest text-zinc-500 font-bold">{item.title}</h3>
                <p className="text-lg font-light text-zinc-400 leading-relaxed">{item.desc}</p>
              </div>
            </Reveal>
          ))}
        </section>

        {/* Founder Section */}
        <section className="pt-24 border-t border-white/5">
          <Reveal>
            <div className="flex flex-col md:flex-row items-center gap-12">
              <motion.div 
                whileHover={{ scale: 1.05 }}
                className="w-48 h-48 rounded-[3rem] bg-gradient-to-tr from-teal-900 via-zinc-900 to-black border border-white/10 flex items-center justify-center relative overflow-hidden group shadow-2xl"
              >
                <User size={80} className="text-teal-500/50 group-hover:text-teal-400 transition-colors duration-500" />
                <div className="absolute inset-0 bg-teal-400/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.div>
              
              <div className="flex-1 space-y-6 text-center md:text-left">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-500 mb-2">Foundation</h4>
                  <h2 className="text-4xl font-semibold text-white tracking-tight">Omkar Dutta</h2>
                  <p className="text-teal-400 font-light mt-2 italic">Founder & Lead Architect</p>
                </div>
                
                <p className="text-lg font-light text-zinc-400 leading-relaxed">
                  Driven by a vision of a more intentional web, Omkar established Vibelink to provide a sanctuary for deep work and high-fidelity social connection. Based in Kolkata, he leads the charge for digital minimalism.
                </p>

                <div className="flex items-center justify-center md:justify-start gap-4">
                  <motion.a 
                    href="https://www.instagram.com/phenomenal.pablo?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    whileHover={{ y: -5 }} 
                    className="p-3 rounded-2xl bg-white/5 text-zinc-400 hover:text-teal-400 hover:bg-white/10 transition-all"
                  >
                    <Instagram size={20} />
                  </motion.a>
                  <motion.a 
                    href="https://www.facebook.com/profile.php?id=100073335111073" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    whileHover={{ y: -5 }} 
                    className="p-3 rounded-2xl bg-white/5 text-zinc-400 hover:text-teal-400 hover:bg-white/10 transition-all"
                  >
                    <Facebook size={20} />
                  </motion.a>
                  <motion.a 
                    href="https://github.com/omkaX-" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    whileHover={{ y: -5 }} 
                    className="p-3 rounded-2xl bg-white/5 text-zinc-400 hover:text-teal-400 hover:bg-white/10 transition-all"
                  >
                    <Github size={20} />
                  </motion.a>
                </div>
              </div>
            </div>
          </Reveal>
        </section>

        <section className="pt-12">
          <Reveal delay={0.8}>
            <p className="text-zinc-600 italic font-light text-center tracking-wide">
              "Designed for the explorers of the digital frontier."
            </p>
          </Reveal>
        </section>
      </div>
    </motion.div>
  );
};

export default Philosophy;
