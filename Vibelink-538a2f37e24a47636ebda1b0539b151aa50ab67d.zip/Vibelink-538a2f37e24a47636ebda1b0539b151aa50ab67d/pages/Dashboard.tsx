
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { storage } from '../store';
import { 
  Send, 
  LayoutDashboard, 
  MessageSquarePlus, 
  LogOut, 
  Users, 
  Settings as SettingsIcon,
  ShieldCheck,
  Check,
  Edit2,
  Trash2,
  History,
  Zap,
  TrendingUp,
  Plus,
  CreditCard
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { InviteRequest, Post } from '../types';
import Reveal from '../components/Reveal';
import MagneticButton from '../components/MagneticButton';
import { useAuth } from '../context/AuthContext';

type Tab = 'overview' | 'announcement' | 'posts' | 'invites' | 'settings_link';

const StatCard = ({ label, value, change, icon: Icon }: { label: string, value: string, change: string, icon: any }) => (
  <div className="bg-zinc-950/50 border border-white/5 rounded-[2rem] p-8 group hover:border-white/10 transition-all">
    <div className="flex items-center justify-between mb-4">
      <p className="text-[10px] text-zinc-500 uppercase tracking-[0.2em] font-bold">{label}</p>
      <Icon size={16} className="text-zinc-700 group-hover:text-white transition-colors" />
    </div>
    <div className="flex items-baseline gap-3">
      <h3 className="text-4xl font-semibold text-white tracking-tighter">{value}</h3>
      <span className="text-xs font-medium text-teal-400">{change}</span>
    </div>
  </div>
);

const Dashboard = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<Tab>('overview');
  const [content, setContent] = useState('');
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [published, setPublished] = useState(false);
  const [invites, setInvites] = useState<InviteRequest[]>([]);
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setInvites(storage.getInvites());
      setPosts(storage.getPosts());
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, [activeTab]);

  const handlePublish = () => {
    if (!content.trim()) return;
    
    if (editingPostId) {
      storage.updatePost(editingPostId, content);
      setEditingPostId(null);
    } else {
      storage.savePost({
        id: Date.now().toString(),
        userId: user?.id || 'current-user',
        authorName: user?.name || 'YOU',
        type: 'thought',
        isFounder: user?.role === 'founder',
        content,
        timestamp: Date.now()
      });
    }

    setContent('');
    setPosts(storage.getPosts());
    setPublished(true);
    setTimeout(() => setPublished(false), 3000);
  };

  const navItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'announcement', label: 'New Signal', icon: Plus },
    { id: 'posts', label: 'Activity', icon: History },
    { id: 'invites', label: 'Invite Pool', icon: Users },
  ] as const;

  return (
    <div className="min-h-[calc(100vh-64px)] flex flex-col md:flex-row bg-black text-[#f5f5f7]">
      <aside className="w-full md:w-64 border-b md:border-b-0 md:border-r border-white/5 p-6 flex flex-col bg-zinc-950/20 apple-blur">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center text-white">
            <Zap size={20} />
          </div>
          <div className="overflow-hidden">
            <h2 className="text-sm font-semibold text-white truncate">{user?.name}</h2>
            <p className="text-[10px] text-zinc-500 uppercase tracking-widest font-bold">Node {user?.id.slice(0, 4)}-Active</p>
          </div>
        </div>

        <nav className="space-y-1 flex-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-all duration-300 ${
                activeTab === item.id 
                ? 'bg-white/5 text-white shadow-[0_0_20px_rgba(255,255,255,0.02)]' 
                : 'text-zinc-500 hover:text-zinc-300 hover:bg-white/[0.02]'
              }`}
            >
              <item.icon size={18} />
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
          <button
            onClick={() => navigate('/settings')}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-zinc-500 hover:text-white hover:bg-white/[0.02] transition-all"
          >
            <SettingsIcon size={18} />
            <span className="font-medium">Settings</span>
          </button>
        </nav>

        <div className="mb-6 p-4 rounded-2xl bg-white/5 border border-white/5">
          <div className="flex items-center gap-2 mb-2">
            <CreditCard size={14} className="text-zinc-500" />
            <span className="text-[10px] uppercase font-bold tracking-widest text-zinc-400">Subscription</span>
          </div>
          <p className="text-xs font-semibold text-white capitalize">{user?.activePackage || 'Free'} Package</p>
          <button 
            onClick={() => navigate('/pricing')}
            className="text-[9px] uppercase font-bold text-teal-400 hover:text-teal-300 mt-2 block"
          >
            Manage Node Plan
          </button>
        </div>

        <button 
          onClick={() => navigate('/')}
          className="mt-auto flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-zinc-600 hover:text-red-400 transition-colors"
        >
          <LogOut size={18} />
          <span className="font-medium">Disconnect</span>
        </button>
      </aside>

      <main className="flex-1 overflow-y-auto p-6 md:p-12">
        <AnimatePresence mode="wait">
          {activeTab === 'overview' && (
            <motion.div key="ov" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-12">
              <header>
                <h1 className="text-4xl font-semibold text-white tracking-tight">Your Presence</h1>
                <p className="text-zinc-500 font-light mt-1">Measuring your resonance within the Kolkata grid.</p>
              </header>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <StatCard label="Resonance Score" value="842" change="+12.4%" icon={TrendingUp} />
                <StatCard label="Signal Nodes" value="24" change="Stable" icon={Users} />
                <StatCard label="Transmissions" value={posts.length.toString()} change="Organic" icon={Zap} />
              </div>

              <section className="space-y-6">
                <h3 className="text-xs uppercase tracking-[0.3em] font-bold text-zinc-600 px-2">Recent Transmission</h3>
                <div className="bg-zinc-950/30 border border-dashed border-white/5 rounded-[2.5rem] p-12 text-center group cursor-pointer hover:border-white/20 transition-all" onClick={() => setActiveTab('announcement')}>
                  <div className="w-16 h-16 rounded-full bg-white/5 mx-auto mb-6 flex items-center justify-center text-zinc-500 group-hover:text-white transition-colors">
                    <Plus size={32} />
                  </div>
                  <p className="text-zinc-500 font-light italic">Drop a new signal into the community flow.</p>
                </div>
              </section>
            </motion.div>
          )}

          {activeTab === 'announcement' && (
            <motion.div key="ann" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="max-w-2xl">
              <header className="mb-8">
                <h1 className="text-4xl font-semibold text-white tracking-tight">Create Moment</h1>
                <p className="text-zinc-500 font-light mt-1">Transmitting high-signal content to your nodes.</p>
              </header>
              <div className="bg-zinc-950/50 border border-white/5 rounded-[2.5rem] p-10 backdrop-blur-xl">
                <textarea
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="What is your current frequency?"
                  className="w-full bg-transparent border-none text-2xl font-light text-white focus:outline-none resize-none min-h-[200px] mb-8 placeholder:text-zinc-800"
                />
                <div className="flex items-center justify-between border-t border-white/5 pt-8">
                  <div className="flex gap-4">
                     <button className="p-3 rounded-2xl bg-white/5 text-zinc-500 hover:text-white transition-colors"><Plus size={20} /></button>
                  </div>
                  <MagneticButton
                    onClick={handlePublish}
                    disabled={!content.trim()}
                    className="flex items-center gap-2 bg-white text-black px-12 py-4 rounded-full font-bold hover:bg-zinc-200 disabled:opacity-20 active:scale-95"
                  >
                    {published ? <Check size={18} /> : 'Transmit'}
                  </MagneticButton>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'posts' && (
            <motion.div key="pst" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="space-y-8">
              <header>
                <h1 className="text-4xl font-semibold text-white tracking-tight">History</h1>
                <p className="text-zinc-500 font-light mt-1">Archive of your digital footprint.</p>
              </header>
              <div className="grid gap-4">
                {posts.length > 0 ? (
                  posts.map(post => (
                    <div key={post.id} className="bg-zinc-950/50 border border-white/5 rounded-3xl p-6 group hover:border-white/10 transition-colors">
                      <p className="text-zinc-300 text-lg font-light italic mb-4">"{post.content}"</p>
                      <div className="flex items-center justify-between border-t border-white/5 pt-4">
                        <span className="text-[10px] text-zinc-600 uppercase tracking-widest font-bold">
                          {new Date(post.timestamp).toLocaleDateString()}
                        </span>
                        <div className="flex gap-2">
                          <button className="p-2 rounded-full hover:bg-white/5 text-zinc-500 hover:text-white transition-all">
                            <Edit2 size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="py-20 text-center text-zinc-700 italic font-light">No transmissions found in this node.</div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
};

export default Dashboard;
