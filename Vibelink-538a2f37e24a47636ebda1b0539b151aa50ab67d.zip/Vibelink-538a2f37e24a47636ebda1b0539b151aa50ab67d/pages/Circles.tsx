
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Plus, Search, Users, Shield, Tag } from 'lucide-react';
import { storage } from '../store';
import { Circle } from '../types';
import { useAuth } from '../context/AuthContext';
import Reveal from '../components/Reveal';
import MagneticButton from '../components/MagneticButton';

const CircleCard: React.FC<{ circle: Circle; onJoin: () => void; isMember: boolean }> = ({ circle, onJoin, isMember }) => {
  const navigate = useNavigate();
  return (
    <motion.div 
      whileHover={{ y: -10 }}
      className="group relative h-96 rounded-[3rem] overflow-hidden bg-zinc-950 border border-white/5 cursor-pointer"
      onClick={() => navigate(`/circles/${circle.id}`)}
    >
      <img src={circle.coverImage} className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:opacity-60 transition-opacity duration-700" alt={circle.name} />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
      
      <div className="absolute bottom-0 left-0 right-0 p-8 space-y-4">
        <div className="flex gap-2">
          {circle.tags.map(tag => (
            <span key={tag} className="text-[10px] uppercase tracking-widest font-bold text-white/40 bg-white/5 px-2 py-0.5 rounded backdrop-blur-md">
              {tag}
            </span>
          ))}
        </div>
        <div>
          <h3 className="text-3xl font-semibold text-white tracking-tight">{circle.name}</h3>
          <p className="text-zinc-400 font-light line-clamp-2 mt-2 leading-relaxed">
            {circle.description}
          </p>
        </div>
        <div className="flex items-center justify-between pt-4 border-t border-white/10">
          <div className="flex items-center gap-2 text-zinc-500 text-xs">
            <Users size={14} />
            <span>{circle.memberCount} Nodes Joined</span>
          </div>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onJoin();
            }}
            className={`px-6 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all ${
              isMember ? 'bg-zinc-800 text-zinc-400' : 'bg-white text-black hover:bg-zinc-200'
            }`}
          >
            {isMember ? 'Joined' : 'Join Circle'}
          </button>
        </div>
      </div>
    </motion.div>
  );
};

const Circles: React.FC = () => {
  const { user } = useAuth();
  const [circles, setCircles] = useState<Circle[]>([]);
  const [search, setSearch] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setCircles(storage.getCircles());
      setIsLoading(false);
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  const handleJoin = (circleId: string) => {
    if (!user) return;
    storage.joinCircle(circleId, user.id);
    setCircles(storage.getCircles());
  };

  const filteredCircles = circles.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.tags.some(t => t.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="max-w-screen-lg mx-auto px-6 py-20 pb-40">
      <header className="mb-16">
        <Reveal>
          <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-4">Ecosystem</h2>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-8">
            <h1 className="text-6xl font-semibold text-white tracking-tighter">Community Circles</h1>
            {user?.role === 'founder' && (
              <MagneticButton className="bg-white text-black px-8 py-3 rounded-full font-bold flex items-center gap-2">
                <Plus size={18} /> Create Circle
              </MagneticButton>
            )}
          </div>
        </Reveal>
      </header>

      <div className="relative mb-16">
        <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-zinc-700" size={20} />
        <input 
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Scan for high-signal communities..."
          className="w-full bg-zinc-950/50 border border-white/5 rounded-[2.5rem] pl-16 pr-8 py-6 text-xl text-white focus:outline-none focus:border-white/10 transition-all placeholder:text-zinc-800"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {isLoading ? (
          [1, 2, 3, 4].map(i => (
            <div key={i} className="h-96 rounded-[3rem] bg-zinc-950 border border-white/5 animate-pulse" />
          ))
        ) : filteredCircles.length > 0 ? (
          filteredCircles.map(circle => (
            <CircleCard 
              key={circle.id} 
              circle={circle} 
              onJoin={() => handleJoin(circle.id)} 
              isMember={user ? storage.getCircleMembers(circle.id).includes(user.id) : false}
            />
          ))
        ) : (
          <div className="col-span-full py-40 text-center">
            <p className="text-zinc-700 italic text-xl font-light">No circles found on this frequency.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Circles;
