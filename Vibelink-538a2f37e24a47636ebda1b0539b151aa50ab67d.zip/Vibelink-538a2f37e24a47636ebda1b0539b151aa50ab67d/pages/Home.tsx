
import React from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Command, ArrowRight, Sparkles, Shield, Cpu, Zap, MessageSquare } from 'lucide-react';
import { useModal } from '../context/ModalContext';
import Reveal from '../components/Reveal';
import MagneticButton from '../components/MagneticButton';
import WeeklyRewards from '../components/WeeklyRewards';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  const { openModal } = useModal();
  const { scrollY } = useScroll();
  const yParallax = useTransform(scrollY, [0, 500], [0, -100]);

  const highlights = [
    { title: "Journal", desc: "No algorithms. No likes. Just intentional thoughts in a shared chronological stream.", path: "/live" },
    { title: "Circles", desc: "Audio and video gatherings designed for presence, not performance.", path: "/circles" },
    { title: "Moments", desc: "Cinematic, full-screen vertical stories that disappear but leave a lasting impression.", path: "/stories" }
  ];

  return (
    <div className="bg-black">
      {/* Hero Section */}
      <motion.section 
        className="flex flex-col items-center justify-center px-6 min-h-[calc(100vh-64px)] text-center relative overflow-hidden"
      >
        <motion.div style={{ y: yParallax }} className="absolute -z-10 opacity-20">
          <div className="w-[800px] h-[800px] bg-gradient-to-tr from-zinc-900 via-white/10 to-transparent rounded-full blur-[150px]" />
        </motion.div>

        <Reveal delay={0.1} direction="down">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className="mb-8 relative"
          >
            <div className="absolute -inset-8 bg-white/5 blur-3xl rounded-full animate-pulse" />
            <Command size={64} className="text-white mx-auto relative z-10" />
          </motion.div>
        </Reveal>

        <Reveal delay={0.3}>
          <h1 className="text-5xl md:text-8xl font-semibold tracking-tighter text-white mb-8 leading-[1.05]">
            This is not a product.<br />
            <span className="text-zinc-600 italic font-light">This is a space.</span>
          </h1>
        </Reveal>

        <Reveal delay={0.5}>
          <p className="text-lg md:text-2xl text-zinc-500 font-light max-w-2xl mx-auto mb-12 leading-relaxed">
            Vibelink is a quiet network for high-signal connections. 
            Designed for those who seek resonance over attention.
          </p>
        </Reveal>

        <Reveal delay={0.7}>
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <MagneticButton 
              onClick={openModal}
              className="bg-white text-black px-12 py-5 rounded-full font-bold shadow-2xl"
            >
              Enter the Space
              <Sparkles size={20} className="group-hover:rotate-12 transition-transform" />
            </MagneticButton>
            
            <Link to="/philosophy">
              <MagneticButton 
                className="text-zinc-400 border border-white/5 bg-white/[0.02] hover:bg-white/5 px-12 py-5 rounded-full transition-all duration-300 backdrop-blur-md"
              >
                The Manifesto
                <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </MagneticButton>
            </Link>
          </div>
        </Reveal>
      </motion.section>

      {/* Weekly Rewards Section */}
      <WeeklyRewards />

      {/* Highlight Grid */}
      <section className="py-40 px-6 border-t border-white/5">
        <div className="max-w-screen-lg mx-auto grid grid-cols-1 md:grid-cols-3 gap-12">
          {highlights.map((h, i) => (
            <Reveal key={i} delay={0.2 * i} direction="up">
              <Link to={h.path} className="block group">
                <div className="p-10 rounded-[3rem] bg-zinc-950/30 border border-white/5 group-hover:border-white/20 transition-all duration-500 h-full flex flex-col">
                  <h3 className="text-xs font-black uppercase tracking-[0.4em] text-zinc-600 mb-6 group-hover:text-white transition-colors">0{i+1} // {h.title}</h3>
                  <p className="text-xl font-light text-zinc-400 leading-relaxed flex-1 italic group-hover:text-zinc-200 transition-colors">
                    "{h.desc}"
                  </p>
                  <div className="mt-8 flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-zinc-700 group-hover:text-teal-400 transition-colors">
                    Access Node <ArrowRight size={12} />
                  </div>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Intentional Bottom CTA */}
      <motion.section 
        className="py-60 px-6 text-center"
      >
        <Reveal>
          <div className="max-w-screen-md mx-auto">
            <h2 className="text-4xl md:text-6xl font-semibold text-white tracking-tighter mb-8 leading-tight">
              Quietly revolutionary.
            </h2>
            <p className="text-zinc-500 text-lg font-light max-w-sm mx-auto mb-12">
              Join 2.4k nodes currently synced in the Kolkata sector.
            </p>
            <MagneticButton 
              onClick={openModal}
              className="px-12 py-5 rounded-full border border-white/10 text-white hover:bg-white hover:text-black transition-all font-bold"
            >
              Sync Identity
            </MagneticButton>
          </div>
        </Reveal>
      </motion.section>
    </div>
  );
};

export default Home;
