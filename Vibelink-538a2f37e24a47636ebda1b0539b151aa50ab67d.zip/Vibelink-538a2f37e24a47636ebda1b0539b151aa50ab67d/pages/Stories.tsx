
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const MOCK_STORIES = [
  { id: '1', imageUrl: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&q=80&w=1080', caption: 'Dawn in the virtual mountains.' },
  { id: '2', imageUrl: 'https://images.unsplash.com/photo-1518005020451-eba75a0460de?auto=format&fit=crop&q=80&w=1080', caption: 'Quiet moments between pixels.' },
  { id: '3', imageUrl: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&q=80&w=1080', caption: 'The signal is getting stronger.' },
];

const STORY_DURATION = 4000;

const SkeletonStory = () => (
  <div className="absolute inset-0 flex items-center justify-center bg-zinc-950 animate-pulse">
    <div className="space-y-6 w-full px-12 text-center">
      <div className="h-8 w-2/3 bg-zinc-900 rounded-lg mx-auto" />
      <div className="h-4 w-1/2 bg-zinc-900 rounded-lg mx-auto opacity-50" />
    </div>
  </div>
);

const Stories: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Initial load simulation
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isLoading) return;

    setProgress(0);
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          setCurrentIndex((curr) => (curr + 1) % MOCK_STORIES.length);
          return 0;
        }
        return prev + (100 / (STORY_DURATION / 100));
      });
    }, 100);

    return () => clearInterval(interval);
  }, [currentIndex, isLoading]);

  const handleNext = () => {
    setCurrentIndex((curr) => (curr + 1) % MOCK_STORIES.length);
    setProgress(0);
  };

  const handlePrev = () => {
    setCurrentIndex((curr) => (curr === 0 ? MOCK_STORIES.length - 1 : curr - 1));
    setProgress(0);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-10 bg-black flex items-center justify-center overflow-hidden pt-16"
    >
      <div className="relative h-full w-full max-w-screen-sm mx-auto overflow-hidden">
        {isLoading ? (
          <SkeletonStory />
        ) : (
          <>
            <div className="absolute top-4 left-4 right-4 z-30 flex gap-2">
              {MOCK_STORIES.map((_, idx) => (
                <div key={idx} className="h-[2px] flex-1 bg-white/20 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-white"
                    initial={{ width: 0 }}
                    animate={{ 
                      width: idx === currentIndex ? `${progress}%` : idx < currentIndex ? '100%' : '0%' 
                    }}
                    transition={{ type: 'tween', ease: 'linear' }}
                  />
                </div>
              ))}
            </div>

            <div className="absolute inset-0 z-20 flex">
              <div className="w-1/2 h-full cursor-pointer" onClick={handlePrev} />
              <div className="w-1/2 h-full cursor-pointer" onClick={handleNext} />
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
                className="absolute inset-0 flex items-center justify-center"
              >
                <img 
                  src={MOCK_STORIES[currentIndex].imageUrl} 
                  alt="Story"
                  className="absolute inset-0 w-full h-full object-cover opacity-60"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent" />
                
                <div className="relative z-10 p-12 text-center">
                  <motion.p 
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="text-2xl md:text-3xl font-light tracking-tight text-white/90 leading-tight"
                  >
                    "{MOCK_STORIES[currentIndex].caption}"
                  </motion.p>
                </div>
              </motion.div>
            </AnimatePresence>

            <div className="absolute inset-0 flex items-center justify-between px-4 z-30 pointer-events-none md:flex hidden">
              <button onClick={handlePrev} className="p-2 rounded-full bg-black/20 backdrop-blur pointer-events-auto hover:bg-black/40 transition-colors">
                <ChevronLeft size={24} />
              </button>
              <button onClick={handleNext} className="p-2 rounded-full bg-black/20 backdrop-blur pointer-events-auto hover:bg-black/40 transition-colors">
                <ChevronRight size={24} />
              </button>
            </div>
          </>
        )}
      </div>
    </motion.div>
  );
};

export default Stories;
