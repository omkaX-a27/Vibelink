
import React from 'react';
import { motion } from 'framer-motion';
import { Check, Sparkles, Zap, Shield, Command } from 'lucide-react';
import Reveal from '../components/Reveal';
import MagneticButton from '../components/MagneticButton';
import PackagesSection from '../components/PackagesSection';

const TESTIMONIALS = [
  {
    quote: "Vibelink isn't just a platform; it's the first time I feel like I actually own my digital presence.",
    name: "Elena Rossi",
    role: "Visual Artist"
  },
  {
    quote: "The quiet minimalism allows my community to actually hear what I'm saying without the algorithmic chaos.",
    name: "Marcus Thorne",
    role: "Product Strategist"
  },
  {
    quote: "I've doubled my audience resonance by moving away from vanity metrics to high-signal connection.",
    name: "Sarah Chen",
    role: "Digital Nomad"
  }
];

const Pricing = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-screen-lg mx-auto px-6 py-24"
    >
      <header className="mb-20 text-center">
        <Reveal>
          <h2 className="text-sm font-medium uppercase tracking-[0.3em] text-zinc-500 mb-4">Investment</h2>
          <h1 className="text-5xl md:text-7xl font-semibold text-white tracking-tighter mb-8 leading-tight">
            Plans for<br />Sovereignty.
          </h1>
          <p className="text-zinc-500 font-light text-lg max-w-sm mx-auto leading-relaxed">
            Choose the fidelity of your connection to the grid. Instant activation available.
          </p>
        </Reveal>
      </header>

      {/* New Interactive Packages Section */}
      <PackagesSection />

      <section className="border-t border-white/5 pt-32">
        <header className="mb-20 text-center">
          <Reveal>
            <h2 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-4">Voices</h2>
            <h3 className="text-4xl font-semibold text-white tracking-tighter">Loved by Creators.</h3>
          </Reveal>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={i} delay={i * 0.2} direction="up">
              <div className="space-y-6">
                <p className="text-xl font-light text-zinc-300 leading-relaxed italic">
                  "{t.quote}"
                </p>
                <div>
                  <h4 className="text-white font-medium">{t.name}</h4>
                  <p className="text-zinc-600 text-xs uppercase tracking-widest mt-1 font-bold">{t.role}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>
    </motion.div>
  );
};

export default Pricing;
