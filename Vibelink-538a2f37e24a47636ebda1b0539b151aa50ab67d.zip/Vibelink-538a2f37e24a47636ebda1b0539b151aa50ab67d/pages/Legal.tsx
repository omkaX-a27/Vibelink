
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Reveal from '../components/Reveal';

const Legal: React.FC = () => {
  const [activeDoc, setActiveDoc] = useState<'tos' | 'privacy'>('tos');

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-screen-md mx-auto px-6 py-24"
    >
      <header className="mb-16">
        <Reveal>
          <h1 className="text-4xl font-semibold text-white tracking-tight mb-8">Legal Framework</h1>
          <div className="flex gap-8 border-b border-white/5">
            <button 
              onClick={() => setActiveDoc('tos')}
              className={`pb-4 text-xs uppercase tracking-[0.2em] font-bold transition-all ${activeDoc === 'tos' ? 'text-white border-b border-white' : 'text-zinc-600 hover:text-zinc-400'}`}
            >
              Terms of Service
            </button>
            <button 
              onClick={() => setActiveDoc('privacy')}
              className={`pb-4 text-xs uppercase tracking-[0.2em] font-bold transition-all ${activeDoc === 'privacy' ? 'text-white border-b border-white' : 'text-zinc-600 hover:text-zinc-400'}`}
            >
              Privacy Policy
            </button>
          </div>
        </Reveal>
      </header>

      <div className="prose prose-invert prose-zinc max-w-none">
        <AnimatePresence mode="wait">
          {activeDoc === 'tos' ? (
            <motion.div 
              key="tos"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              className="text-zinc-400 font-light space-y-12 leading-relaxed"
            >
              <section className="space-y-4">
                <h2 className="text-xl font-medium text-white tracking-tight">1. Acceptance of Terms</h2>
                <p>By accessing Vibelink, you agree to bound by these Terms of Service. Vibelink is a curated digital space provided for intentional connection and high-signal sharing.</p>
              </section>

              <section className="space-y-4">
                <h2 className="text-xl font-medium text-white tracking-tight">2. Conduct and Ethics</h2>
                <p>Users are expected to contribute to a signal-heavy environment. Low-resonance behavior, spamming, or noise pollution is grounds for node disconnection.</p>
              </section>

              <section className="space-y-4">
                <h2 className="text-xl font-medium text-white tracking-tight">3. Sovereign Content</h2>
                <p>You retain full ownership of the data you transmit. Vibelink provides the infrastructure, but you own the signal.</p>
              </section>

              <section className="space-y-4 italic text-xs text-zinc-600">
                Last Updated: October 2024
              </section>
            </motion.div>
          ) : (
            <motion.div 
              key="privacy"
              initial={{ opacity: 0, x: 10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -10 }}
              className="text-zinc-400 font-light space-y-12 leading-relaxed"
            >
              <section className="space-y-4">
                <h2 className="text-xl font-medium text-white tracking-tight">1. Data Minimization</h2>
                <p>We believe in digital sanctuary. We collect only the minimum required data to maintain your signal link. We do not sell, rent, or lease your identity to third parties.</p>
              </section>

              <section className="space-y-4">
                <h2 className="text-xl font-medium text-white tracking-tight">2. Encryption</h2>
                <p>All private transmissions are encrypted at the infrastructure level. Your thoughts and moments are for your intended audience only.</p>
              </section>

              <section className="space-y-4">
                <h2 className="text-xl font-medium text-white tracking-tight">3. Right to Forget</h2>
                <p>Vibelink is built with the principle of ephemerality. You have the right to purge your node at any time, leaving no digital footprint on our grid.</p>
              </section>

              <section className="space-y-4 italic text-xs text-zinc-600">
                Last Updated: October 2024
              </section>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default Legal;
