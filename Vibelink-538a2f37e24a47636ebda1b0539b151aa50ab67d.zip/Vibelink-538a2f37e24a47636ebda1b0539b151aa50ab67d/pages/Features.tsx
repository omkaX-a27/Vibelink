
import React from 'react';
import { motion } from 'framer-motion';
import { 
  MessageSquare, 
  Tv, 
  ShoppingBag, 
  Lock, 
  BarChart3, 
  MessageCircle, 
  Zap, 
  Shield 
} from 'lucide-react';
import Reveal from '../components/Reveal';

const FEATURES_LIST = [
  {
    icon: MessageSquare,
    title: "Real‑time Social Feed",
    description: "A chronological, noise-free stream of consciousness from your curated signal nodes."
  },
  {
    icon: Tv,
    title: "Live Streaming & Events",
    description: "High-fidelity video broadcasts and intimate audio gatherings with zero latency."
  },
  {
    icon: ShoppingBag,
    title: "Creator Marketplace",
    description: "A boutique space to exchange digital goods, services, and creative assets directly."
  },
  {
    icon: Lock,
    title: "Exclusive Subscriber Content",
    description: "Deep-tier access for your inner circle. Sovereign monetization on your own terms."
  },
  {
    icon: BarChart3,
    title: "Analytics Dashboard",
    description: "Privacy-first metrics that measure resonance rather than just vanity numbers."
  },
  {
    icon: MessageCircle,
    title: "In‑App Chat & Notifications",
    description: "Quiet, intentional messaging designed to facilitate deep connection, not distraction."
  },
  {
    icon: Shield,
    title: "Signal Sovereignty",
    description: "Total control over who sees your data. We don't sell attention; we facilitate resonance."
  },
  {
    icon: Zap,
    title: "Frictionless Utility",
    description: "Designed for entrepreneurs and influencers who need tools that get out of the way."
  }
];

// Fix: Remove React.FC to bypass TS errors that mandate children props
const Features = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-screen-md mx-auto px-6 py-24"
    >
      <header className="mb-20 text-center">
        <Reveal>
          <h2 className="text-sm font-medium uppercase tracking-[0.3em] text-zinc-500 mb-4">Core Infrastructure</h2>
          <h1 className="text-5xl md:text-7xl font-semibold text-white tracking-tighter mb-8 leading-tight">
            High-Signal<br />Capabilities.
          </h1>
          <p className="text-zinc-500 font-light text-lg max-w-sm mx-auto leading-relaxed">
            The fundamental modules that power the Vibelink sanctuary.
          </p>
        </Reveal>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-16">
        {FEATURES_LIST.map((feature, idx) => (
          <Reveal key={idx} delay={idx * 0.1} direction="up">
            <div className="group">
              <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mb-6 group-hover:bg-teal-400 group-hover:text-black transition-all duration-500">
                <feature.icon size={24} />
              </div>
              <h3 className="text-xl font-medium text-white mb-3 tracking-tight">{feature.title}</h3>
              <p className="text-zinc-500 font-light leading-relaxed text-sm md:text-base">
                {feature.description}
              </p>
            </div>
          </Reveal>
        ))}
      </div>

      <section className="mt-32 pt-24 border-t border-white/5 text-center">
        <Reveal>
          <h3 className="text-xs font-bold uppercase tracking-[0.4em] text-zinc-600 mb-8">Target Audience</h3>
          <div className="flex flex-wrap justify-center gap-4 text-sm font-light text-zinc-400 italic">
            <span>Creators •</span>
            <span>Influencers •</span>
            <span>Entrepreneurs •</span>
            <span>Digital Marketers •</span>
            <span>Community Leaders</span>
          </div>
        </Reveal>
      </section>
    </motion.div>
  );
};

export default Features;
